(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[22],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/add.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/property/add.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_form_wizard__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-form-wizard */ "./node_modules/vue-form-wizard/dist/vue-form-wizard.js");
/* harmony import */ var vue_form_wizard__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_form_wizard__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var vue_form_wizard_dist_vue_form_wizard_min_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! vue-form-wizard/dist/vue-form-wizard.min.css */ "./node_modules/vue-form-wizard/dist/vue-form-wizard.min.css");
/* harmony import */ var vue_form_wizard_dist_vue_form_wizard_min_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(vue_form_wizard_dist_vue_form_wizard_min_css__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var vee_validate__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! vee-validate */ "./node_modules/vee-validate/dist/vee-validate.esm.js");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




 // For custom error message


var dict = {
  custom: {
    property_name: {
      required: 'Institute Name is Required',
      alpha: "Institute Name may only contain alphabetic characters"
    },
    property_type: {
      required: 'Institute Type is Required'
    },
    property_description: {
      required: 'Short Description is Required'
    },
    language_spoken: {
      required: 'Language Spoken is Required'
    },
    meal_option: {
      required: 'Meal Option is Required'
    },
    hotel_contact: {
      required: 'Contact Number is Required'
    },
    property_size: {
      required: 'Property Size is Required'
    },
    email: {
      required: 'Email is Required'
    },
    parking: {
      required: 'Parking is Required'
    },
    village_name: {
      required: 'Village Name is Required'
    },
    district_name: {
      required: 'District Name is Required'
    },
    road_name: {
      required: 'Road Name is Required'
    },
    pincode: {
      required: 'PinCode is Required'
    }
  }
}; // register custom messages

vee_validate__WEBPACK_IMPORTED_MODULE_5__["Validator"].localize('en', dict);
/* harmony default export */ __webpack_exports__["default"] = ({
  // props: {
  //     data: {
  //         type: Object,
  //         required: true,
  //     },
  // },
  data: function data() {
    return {
      twitter: "",
      facebook: "",
      instagram: "",
      // data_local: JSON.parse(JSON.stringify(this.data)),
      property_name: "",
      email: "",
      parkingSelect: "0",
      propSize: "",
      village: "",
      policy: "",
      district: "",
      roadName: "",
      images: [],
      selectedFiles: [],
      pinCode: "",
      citySelect: "",
      stateSelect: "",
      RoomLength: "",
      RoomBreadth: "",
      roomName: "",
      beds: "",
      noofbeds: "",
      addressValue: "",
      maximum_guest: "",
      attach_bathroom: "",
      selectedFeatured: null,
      selectedCategory: "",
      EmailEnter: "",
      Hotel: "",
      Language: "",
      extra_bed: "",
      url: null,
      length: "",
      breadth: "",
      textarea: "",
      eventName: "",
      eventLocation: "san-francisco",
      status: "plannning",
      room_card: [],
      managers: [],
      amenities: [],
      selectedClass: '',
      currPropId: null,
      policyContent: [],
      b2bprice: "",
      roomTypeOptions: [{
        name: 'Premium',
        id: 1
      }, {
        name: 'Deluxe',
        id: 2
      }, {
        name: 'Normal',
        id: 3
      }],
      cityOptions: [{
        name: 'Chopta',
        id: 48357
      }],
      stateOptions: [{
        name: 'Uttarakhand',
        id: 39
      }],
      classes: ['danger', 'primary', 'success', 'rgb(32, 201, 192)'],
      min: 1,
      max: 3,
      number: 0,
      gallery: [],
      managersSelect: null,
      amenitiesValue: [],
      room_type: "",
      social: [],
      image: null,
      originalImage: null,
      bedOptions: [{
        text: "1",
        value: 1
      }, {
        text: "2",
        value: 2
      }, {
        text: "3",
        value: 3
      }, {
        text: "4",
        value: 4
      }],
      maximumGuestOptions: [{
        text: "1",
        value: 1
      }, {
        text: "2",
        value: 2
      }, {
        text: "3",
        value: 3
      }, {
        text: "4",
        value: 4
      }, {
        text: "5",
        value: 5
      }, {
        text: "6",
        value: 6
      }, {
        text: "7",
        value: 7
      }, {
        text: "8",
        value: 8
      }, {
        text: "9",
        value: 9
      }, {
        text: "10",
        value: 10
      }],
      categories: [],
      MealOption: [],
      MealOptionExclude: [],
      bathroomOptions: [{
        text: "Yes",
        value: 1
      }, {
        text: "No",
        value: 0
      }]
    };
  },
  created: function created() {
    this.getRandomNumber();
  },
  methods: {
    validateStep1: function validateStep1() {
      var _this = this;

      return new Promise(function (resolve, reject) {
        _this.$validator.validateAll('step-1').then(function (result) {
          if (result) {
            _this.$vs.loading();

            var bodyFormData = new FormData();
            bodyFormData.append('name', _this.property_name);
            bodyFormData.append('language', _this.Language);
            bodyFormData.append('type', _this.selectedCategory);
            bodyFormData.append('description', _this.textarea);
            bodyFormData.append('email', _this.EmailEnter);
            bodyFormData.append('hotel', Number(_this.Hotel));
            bodyFormData.append('logo', _this.originalImage);
            axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/step1', bodyFormData).then(function (res) {
              console.log(res);

              if (res.data['success'] == 1) {
                _this.$vs.loading.close();

                _this.currPropId = res.data['prop'];
                resolve(true); // this.getState()
                // this.getCity()
              }
            }).catch(function (err) {
              _this.$vs.loading.close();

              console.log(err);
            }); // resolve(true)
          } else {
            reject("correct all values");
          }
        });
      });
    },
    validateStep4: function validateStep4() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        _this2.$validator.validateAll("step-4").then(function (result) {
          if (result) {
            _this2.$vs.loading();

            axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/step2', {
              prop_id: _this2.currPropId,
              village: _this2.village,
              district: _this2.district,
              road: _this2.roadName,
              pin: Number(_this2.pinCode),
              state: Number(_this2.stateSelect),
              city: Number(_this2.citySelect),
              address: _this2.addressValue
            }).then(function (res) {
              if (res.data['status'] == 1) {
                _this2.$vs.loading.close();

                resolve(true);
              }
            }).catch(function (err) {
              reject("correct all values");
              console.log(err);
            });
          } else {
            reject("correct all values");
          }
        });
      });
    },
    validateStep3: function validateStep3() {
      var _this3 = this;

      return new Promise(function (resolve, reject) {
        _this3.$validator.validateAll("step-3").then(function (result) {
          if (result) {
            _this3.$vs.loading();

            axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/step3', {
              amenities: _this3.amenitiesValue,
              prop_id: _this3.currPropId
            }).then(function (res) {
              if (res.data['status'] == 1) {
                _this3.$vs.loading.close();

                resolve(true);
              }
            }).catch(function (err) {
              console.log(err);
            });
          } else {
            reject("correct all values");
          }
        });
      });
    },
    validateStep2: function validateStep2() {
      var _this4 = this;

      return new Promise(function (resolve, reject) {
        _this4.$validator.validateAll("step-2").then(function (result) {
          if (result) {
            _this4.social.push({
              name: "twitter",
              links: _this4.twitter
            });

            _this4.social.push({
              name: "facebook",
              links: _this4.facebook
            });

            _this4.social.push({
              name: "instagram",
              links: _this4.instagram
            });

            var bodyFormData = new FormData();
            bodyFormData.append('prop_id', _this4.currPropId);

            _this4.social.forEach(function (item) {
              bodyFormData.append('name[]', item.name);
              bodyFormData.append('links[]', item.links);
            });

            axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/step4', bodyFormData).then(function (res) {
              if (res.data['status'] == 1) {
                _this4.$vs.loading.close();

                resolve(true);
              }
            }).catch(function (err) {
              _this4.$vs.loading.close();

              console.log(err);
              reject("Server Error");
            });
          } else {
            reject("correct all values");
          }
        });
      });
    },
    validateStep5: function validateStep5() {
      var _this5 = this;

      return new Promise(function (resolve, reject) {
        _this5.$validator.validateAll("step-5").then(function (result) {
          if (result) {
            var imgVal = jquery__WEBPACK_IMPORTED_MODULE_4___default()('#featuredImage').val();
            var multiimgVal = jquery__WEBPACK_IMPORTED_MODULE_4___default()('#galleryImage').val();

            if (imgVal == '') {
              _this5.alert('Select Featured Image', 'Featured Image Not Selected', 'danger');

              reject("correct all values");
            } else if (multiimgVal == '') {
              _this5.alert('Select Gallery Image', 'Gallery Images Not Selected', 'danger');

              reject("correct all values");
            } else {
              _this5.$vs.loading();

              var data = new FormData(); // for( var i = 0; i < this.images.length; i++ ){
              //     let file = this.images[i];
              //
              //     data.append('files[' + i + ']', file);
              // }

              console.log('featured: ' + _this5.selectedFeatured, 'gallery: ' + _this5.images);
              data.append('featured', _this5.selectedFeatured); // data.append('gallery', this.images);

              data.append('prop_id', _this5.currPropId);
              axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/step5', data, {
                headers: {
                  'Content-Type': 'multipart/form-data',
                  'Accept': 'application/json'
                }
              }).then(function (res) {
                console.log(res);

                if (res.data['status'] == 1) {
                  var ima = new FormData();

                  for (var i = 0; i < _this5.images.length; i++) {
                    var file = _this5.images[i];
                    ima.append('files[' + i + ']', file);
                  }

                  ima.append('prop_id', _this5.currPropId);
                  axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/gallery', ima, {
                    headers: {
                      'Content-Type': 'multipart/form-data',
                      'Accept': 'application/json'
                    }
                  }).then(function (res) {
                    console.log(res);

                    if (res.data['status'] == 1) {
                      _this5.$vs.loading.close();

                      resolve(true);
                    } else {
                      _this5.$vs.loading.close();

                      reject("Server Error");
                    }
                  }).catch(function (err) {
                    _this5.$vs.loading.close();

                    console.log(err);
                    reject("Server Error");
                  });
                } else {
                  _this5.$vs.loading.close();

                  reject("Server Error");
                }
              }).catch(function (err) {
                _this5.$vs.loading.close();

                console.log(err);
                reject("Server Error");
              });
            }
          } else {
            reject("correct all values");
          }
        });
      });
    },
    validateStep6: function validateStep6() {
      var _this6 = this;

      return new Promise(function (resolve, reject) {
        _this6.$validator.validateAll("step-6").then(function (result) {
          if (result) {
            if (_this6.policy == "") {
              reject("correct all values");

              _this6.alert('Policy Not Agreed', 'Please Agree to Our Policy', 'danger');
            } else {
              resolve(true);
            }
          } else {
            reject("correct all values");
          }
        });
      });
    },
    validateStep7: function validateStep7() {
      var _this7 = this;

      return new Promise(function (resolve, reject) {
        _this7.$validator.validateAll("step-7").then(function (result) {
          if (result) {
            _this7.$vs.loading();

            axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/properties/submit', {
              prop_id: _this7.currPropId
            }).then(function (res) {
              if (res.data['status'] == 1) {
                resolve(true);
                document.getElementById('fomrWizard').style.display = 'none';
                document.getElementById('SuccessDone').style.display = 'block';

                _this7.$vs.loading.close();
              }
            }).catch(function (err) {
              _this7.$vs.loading.close();

              console.log(err);
              reject("Server Error");
            });
          } else {
            reject("correct all values");
          }
        });
      });
    },
    galleryImage: function galleryImage() {
      alert(this.gallery);
    },
    getManagers: function getManagers() {
      var _this8 = this;

      axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/users/managers').then(function (res) {
        console.log(res);
        _this8.managers = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getAmen: function getAmen() {
      var _this9 = this;

      axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/amenities/get').then(function (res) {
        console.log(res);
        _this9.amenities = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getCat: function getCat() {
      var _this10 = this;

      axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/categories/getNames').then(function (res) {
        console.log(res);
        _this10.categories = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    showImage: function showImage(e) {
      var file = e.target.files[0];
      this.originalImage = file;
      this.image = URL.createObjectURL(file);
    },
    getState: function getState() {
      var _this11 = this;

      axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/state/get').then(function (res) {
        console.log(res);
        _this11.stateOptions = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getCity: function getCity() {
      var _this12 = this;

      axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/city/get').then(function (res) {
        console.log(res);
        _this12.cityOptions = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    resetGallery: function resetGallery() {
      document.getElementById("galleryImage").value = "";
      this.images = [];
      this.selectedFiles = [];
    },
    deleteUpload: function deleteUpload(event) {
      console.log("Delete:" + JSON.stringify(event));
    },
    createRoom: function createRoom() {
      var room = jquery__WEBPACK_IMPORTED_MODULE_4___default()("#room_card").clone();
      var $div = jquery__WEBPACK_IMPORTED_MODULE_4___default()('.cloneDiv[id^="room_card"]:last'); // Read the Number from that DIV's ID (i.e: 3 from "klon3")
      // And increment that number by 1

      var num = parseInt($div.prop("id").match(/\d+/g), 10) + 1; // Clone it and assign the new ID (i.e: from num 4 to ID "klon4")

      var $klon = $div.clone().prop('id', 'room_card' + num);
      jquery__WEBPACK_IMPORTED_MODULE_4___default()("#copy_room").append($klon);
      jquery__WEBPACK_IMPORTED_MODULE_4___default()("html, body").animate({
        scrollTop: jquery__WEBPACK_IMPORTED_MODULE_4___default()(document).height()
      }, 1000);
    },
    successUpload: function successUpload(event) {
      console.log(event);
    },
    getPolicy: function getPolicy() {
      var _this13 = this;

      axios__WEBPACK_IMPORTED_MODULE_3___default.a.post('/api/policies/get').then(function (res) {
        console.log(res);
        _this13.policyContent = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    removeMeal: function removeMeal() {
      this.MealOption = [];
    },
    removeMealE: function removeMealE() {
      this.MealOptionExclude = [];
    },
    removeRoom: function removeRoom(elem) {
      alert("Clicked");
      alert(jquery__WEBPACK_IMPORTED_MODULE_4___default()(elem).parent('div').attr('id'));
    },
    loadNum: function loadNum() {
      this.min = 0;
      this.max = 3;
      this.getRandomNumber();
    },
    getInput: function getInput() {
      var min = Number(this.min);
      var max = Number(this.max);

      if (min > max) {
        var _ref = [max, min];
        min = _ref[0];
        max = _ref[1];
      }

      this.min = min;
      this.max = max;
      this.getRandomNumber();
    },
    onFileChange: function onFileChange(e) {
      var file = e.target.files[0];
      this.selectedFeatured = file;
      this.url = URL.createObjectURL(file);
    },
    uploadImage: function uploadImage(e) {
      var _this14 = this;

      var vm = this;
      var selectedFiles = e.target.files;

      for (var i = 0; i < selectedFiles.length; i++) {
        console.log(selectedFiles[i]);
        this.images.push(selectedFiles[i]);
      }

      var _loop = function _loop(_i) {
        var reader = new FileReader();

        reader.onload = function (e) {
          _this14.$refs.image[_i].src = reader.result;
          console.log(_this14.$refs.image[_i].src);
        };

        reader.readAsDataURL(_this14.images[_i]);
      };

      for (var _i = 0; _i < this.images.length; _i++) {
        _loop(_i);
      }
    },
    getRandomNumber: function getRandomNumber() {
      this.number = this.generateNumber();
    },
    generateNumber: function generateNumber() {
      return Math.floor(Math.random() * (this.max - this.min + 1) + this.min);
    },
    alert: function alert(title, text, color) {
      this.$vs.notify({
        color: color,
        title: title,
        text: text,
        position: 'top-right'
      });
    },
    gotoList: function gotoList() {
      this.$router.push('/property/all').catch(function () {});
    },
    handleClick: function handleClick(e) {
      if (e.target.matches('.cloneButton, .cloneButton *')) {}
    }
  },
  components: {
    FormWizard: vue_form_wizard__WEBPACK_IMPORTED_MODULE_0__["FormWizard"],
    TabContent: vue_form_wizard__WEBPACK_IMPORTED_MODULE_0__["TabContent"],
    'v-select': vue_select__WEBPACK_IMPORTED_MODULE_2___default.a
  },
  beforeMount: function beforeMount() {
    this.getManagers();
    this.getAmen();
    this.getPolicy();
    this.getCat();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/add.vue?vue&type=template&id=1629bbf1&":
/*!**************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/property/add.vue?vue&type=template&id=1629bbf1& ***!
  \**************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Colleges" } },
    [
      _c(
        "form-wizard",
        {
          ref: "wizard",
          attrs: {
            id: "fomrWizard",
            color: "rgba(var(--vs-primary), 1)",
            errorColor: "rgba(var(--vs-danger), 1)",
            title: null,
            subtitle: null,
            finishButtonText: "Submit"
          }
        },
        [
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Basic Info",
                icon: "feather icon-briefcase",
                "before-change": _vm.validateStep1
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-1" } }, [
                _c("div", { staticClass: "vx-row" }, [
                  _c(
                    "div",
                    { staticClass: "vx-col w-full" },
                    [
                      _vm.image
                        ? _c("img", {
                            staticStyle: { "max-width": "40%" },
                            attrs: { src: _vm.image }
                          })
                        : _vm._e(),
                      _vm._v(" "),
                      _c("input", {
                        ref: "uploadImgInput",
                        staticClass: "hidden",
                        attrs: { type: "file", accept: "image/*" },
                        on: { change: _vm.showImage }
                      }),
                      _vm._v(" "),
                      _c(
                        "vs-button",
                        {
                          on: {
                            click: function($event) {
                              return _vm.$refs.uploadImgInput.click()
                            }
                          }
                        },
                        [_vm._v("Upload Logo")]
                      ),
                      _c("br"),
                      _vm._v(" "),
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required|alpha_spaces",
                            expression: "'required|alpha_spaces'"
                          }
                        ],
                        staticClass: "w-full mt-4",
                        attrs: {
                          label: "Institute Name",
                          type: "text",
                          name: "property_name"
                        },
                        model: {
                          value: _vm.property_name,
                          callback: function($$v) {
                            _vm.property_name = $$v
                          },
                          expression: "property_name"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-2.property_name")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col w-full" },
                    [
                      _c("vs-textarea", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "md:mt-10 mt-6 mb-0",
                        attrs: {
                          label: "Description",
                          name: "property_description",
                          rows: "3"
                        },
                        model: {
                          value: _vm.textarea,
                          callback: function($$v) {
                            _vm.textarea = $$v
                          },
                          expression: "textarea"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(
                          _vm._s(
                            _vm.errors.first("step-2.property_description")
                          )
                        )
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required|alpha_spaces",
                            expression: "'required|alpha_spaces'"
                          }
                        ],
                        staticClass: "w-full mt-4",
                        attrs: {
                          label: "Language Spoken",
                          name: "language_spoken"
                        },
                        model: {
                          value: _vm.Language,
                          callback: function($$v) {
                            _vm.Language = $$v
                          },
                          expression: "Language"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(
                          _vm._s(_vm.errors.first("step-2.language_spoken"))
                        )
                      ]),
                      _vm._v(" "),
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required|",
                            expression: "'required|'"
                          }
                        ],
                        staticClass: "w-full mt-4",
                        attrs: {
                          label: "Contact Number",
                          name: "hotel_contact"
                        },
                        model: {
                          value: _vm.Hotel,
                          callback: function($$v) {
                            _vm.Hotel = $$v
                          },
                          expression: "Hotel"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-2.hotel_contact")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full" },
                    [
                      _c(
                        "vs-select",
                        {
                          staticClass: "w-full select-large mt-5",
                          attrs: { label: "Room Type" },
                          model: {
                            value: _vm.noofbeds,
                            callback: function($$v) {
                              _vm.noofbeds = $$v
                            },
                            expression: "noofbeds"
                          }
                        },
                        [
                          _c("vs-select-item", {
                            staticClass: "w-full",
                            attrs: { value: "1", text: "Shared" }
                          }),
                          _vm._v(" "),
                          _c("vs-select-item", {
                            staticClass: "w-full",
                            attrs: { value: "2", text: "Private" }
                          })
                        ],
                        1
                      ),
                      _vm._v(" "),
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required|",
                            expression: "'required|'"
                          }
                        ],
                        staticClass: "w-full mt-4",
                        attrs: { label: "Email", name: "email" },
                        model: {
                          value: _vm.EmailEnter,
                          callback: function($$v) {
                            _vm.EmailEnter = $$v
                          },
                          expression: "EmailEnter"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-2.email")))
                      ])
                    ],
                    1
                  )
                ])
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Social Links",
                icon: "feather icon-image",
                "before-change": _vm.validateStep2
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-2" } }, [
                _c("div", { staticClass: "vx-row" }, [
                  _c(
                    "div",
                    { staticClass: "vx-col w-full md:w-1/2" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "url:require_protocol",
                            expression: "'url:require_protocol'"
                          }
                        ],
                        staticClass: "w-full",
                        attrs: {
                          "icon-pack": "feather",
                          icon: "icon-twitter",
                          label: "Twitter",
                          "icon-no-border": "",
                          name: "twitter"
                        },
                        model: {
                          value: _vm.twitter,
                          callback: function($$v) {
                            _vm.twitter = $$v
                          },
                          expression: "twitter"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("twitter"),
                              expression: "errors.has('twitter')"
                            }
                          ],
                          staticClass: "text-danger text-sm"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("twitter")))]
                      ),
                      _vm._v(" "),
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "url:require_protocol",
                            expression: "'url:require_protocol'"
                          }
                        ],
                        staticClass: "w-full mt-4",
                        attrs: {
                          "icon-pack": "feather",
                          icon: "icon-facebook",
                          label: "Facebook",
                          "icon-no-border": "",
                          name: "facebook"
                        },
                        model: {
                          value: _vm.facebook,
                          callback: function($$v) {
                            _vm.facebook = $$v
                          },
                          expression: "facebook"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("facebook"),
                              expression: "errors.has('facebook')"
                            }
                          ],
                          staticClass: "text-danger text-sm"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("facebook")))]
                      ),
                      _vm._v(" "),
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "url:require_protocol",
                            expression: "'url:require_protocol'"
                          }
                        ],
                        staticClass: "w-full mt-4",
                        attrs: {
                          "icon-pack": "feather",
                          icon: "icon-instagram",
                          label: "Instagram",
                          "icon-no-border": "",
                          name: "instagram"
                        },
                        model: {
                          value: _vm.instagram,
                          callback: function($$v) {
                            _vm.instagram = $$v
                          },
                          expression: "instagram"
                        }
                      }),
                      _vm._v(" "),
                      _c(
                        "span",
                        {
                          directives: [
                            {
                              name: "show",
                              rawName: "v-show",
                              value: _vm.errors.has("instagram"),
                              expression: "errors.has('instagram')"
                            }
                          ],
                          staticClass: "text-danger text-sm"
                        },
                        [_vm._v(_vm._s(_vm.errors.first("instagram")))]
                      )
                    ],
                    1
                  )
                ])
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Amenities",
                icon: "feather icon-image",
                "before-change": _vm.validateStep3
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-3" } }, [
                _c(
                  "div",
                  { staticClass: "vx-row" },
                  [
                    _c(
                      "vs-tabs",
                      { attrs: { color: "rgb(32, 201, 192)" } },
                      [
                        this.getRandomNumber
                          ? _c(
                              "vs-tabs",
                              {
                                attrs: {
                                  position: "left",
                                  color: _vm.classes[_vm.number]
                                }
                              },
                              [
                                _vm._l(_vm.amenities, function(item, index) {
                                  return _c(
                                    "vs-tab",
                                    { key: index, attrs: { label: item.name } },
                                    [
                                      _c("span", [
                                        _c(
                                          "ul",
                                          { staticClass: "demo-alignment" },
                                          _vm._l(
                                            _vm.amenities[index].children,
                                            function(items, indexs) {
                                              return _c(
                                                "li",
                                                { key: indexs },
                                                [
                                                  _c(
                                                    "vs-checkbox",
                                                    {
                                                      attrs: {
                                                        "vs-value": items.id
                                                      },
                                                      model: {
                                                        value:
                                                          _vm.amenitiesValue,
                                                        callback: function(
                                                          $$v
                                                        ) {
                                                          _vm.amenitiesValue = $$v
                                                        },
                                                        expression:
                                                          "amenitiesValue"
                                                      }
                                                    },
                                                    [_vm._v(_vm._s(items.name))]
                                                  )
                                                ],
                                                1
                                              )
                                            }
                                          ),
                                          0
                                        )
                                      ])
                                    ]
                                  )
                                }),
                                _vm._v(" "),
                                _c("vs-tab", {
                                  attrs: {
                                    disabled: true,
                                    label: "Select Amenities"
                                  }
                                })
                              ],
                              2
                            )
                          : _vm._e()
                      ],
                      1
                    )
                  ],
                  1
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Address",
                icon: "feather icon-image",
                "before-change": _vm.validateStep4
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-4" } }, [
                _c("div", { staticClass: "vx-row" }, [
                  _c(
                    "div",
                    { staticClass: "vx-col w-full" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "w-full mt-5",
                        attrs: { label: "Address", name: "address_text" },
                        model: {
                          value: _vm.addressValue,
                          callback: function($$v) {
                            _vm.addressValue = $$v
                          },
                          expression: "addressValue"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-3.address_text")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "w-full mt-5",
                        attrs: { label: "Village", name: "village_name" },
                        model: {
                          value: _vm.village,
                          callback: function($$v) {
                            _vm.village = $$v
                          },
                          expression: "village"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-3.village_name")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "w-full mt-5",
                        attrs: { label: "District", name: "district_name" },
                        model: {
                          value: _vm.district,
                          callback: function($$v) {
                            _vm.district = $$v
                          },
                          expression: "district"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-3.district_name")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "w-full mt-5",
                        attrs: { label: "Road Name", name: "road_name" },
                        model: {
                          value: _vm.roadName,
                          callback: function($$v) {
                            _vm.roadName = $$v
                          },
                          expression: "roadName"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-3.road_name")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                    [
                      _c("vs-input", {
                        directives: [
                          {
                            name: "validate",
                            rawName: "v-validate",
                            value: "required",
                            expression: "'required'"
                          }
                        ],
                        staticClass: "w-full mt-5",
                        attrs: { label: "Pin Code", name: "pincode" },
                        model: {
                          value: _vm.pinCode,
                          callback: function($$v) {
                            _vm.pinCode = $$v
                          },
                          expression: "pinCode"
                        }
                      }),
                      _vm._v(" "),
                      _c("span", { staticClass: "text-danger" }, [
                        _vm._v(_vm._s(_vm.errors.first("step-3.pincode")))
                      ])
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                    [
                      _c(
                        "vs-select",
                        {
                          staticClass: "w-full select-large",
                          attrs: { label: "City" },
                          model: {
                            value: _vm.citySelect,
                            callback: function($$v) {
                              _vm.citySelect = $$v
                            },
                            expression: "citySelect"
                          }
                        },
                        _vm._l(_vm.cityOptions, function(item, index) {
                          return _c("vs-select-item", {
                            key: index,
                            staticClass: "w-full",
                            attrs: { value: item.id, text: item.name }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                    [
                      _c(
                        "vs-select",
                        {
                          staticClass: "w-full select-large",
                          attrs: { label: "State" },
                          model: {
                            value: _vm.stateSelect,
                            callback: function($$v) {
                              _vm.stateSelect = $$v
                            },
                            expression: "stateSelect"
                          }
                        },
                        _vm._l(_vm.stateOptions, function(item, index) {
                          return _c("vs-select-item", {
                            key: index,
                            staticClass: "w-full",
                            attrs: { value: item.id, text: item.name }
                          })
                        }),
                        1
                      )
                    ],
                    1
                  )
                ])
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Photos",
                icon: "feather icon-image",
                "before-change": _vm.validateStep5
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-5" } }, [
                _c("div", { staticClass: "vx-row" }, [
                  _c(
                    "div",
                    { staticClass: "vx-col w-full" },
                    [
                      _c(
                        "vx-card",
                        {
                          staticClass: "mt-3",
                          attrs: { title: "Featured Image" }
                        },
                        [
                          _c("vs-row", [
                            _c("div", { staticClass: "vs-col" }, [
                              _c(
                                "div",
                                {
                                  staticClass: "con-input-upload",
                                  staticStyle: {
                                    float: "unset",
                                    width: "100% !important"
                                  }
                                },
                                [
                                  _c("input", {
                                    attrs: {
                                      type: "file",
                                      id: "featuredImage"
                                    },
                                    on: { change: _vm.onFileChange }
                                  }),
                                  _c("span", { staticClass: "text-input" }, [
                                    _vm._v(" Upload File ")
                                  ]),
                                  _c("span", {
                                    staticClass: "input-progress",
                                    staticStyle: { width: "0%" }
                                  }),
                                  _c(
                                    "button",
                                    {
                                      staticClass:
                                        "btn-upload-all vs-upload--button-upload",
                                      attrs: {
                                        disabled: "disabled",
                                        type: "button",
                                        title: "Upload"
                                      }
                                    },
                                    [
                                      _c(
                                        "i",
                                        {
                                          staticClass:
                                            "material-icons notranslate",
                                          attrs: { translate: "translate" }
                                        },
                                        [_vm._v(" cloud_upload ")]
                                      )
                                    ]
                                  )
                                ]
                              )
                            ]),
                            _vm._v(" "),
                            _c(
                              "div",
                              {
                                staticClass: "vs-col",
                                staticStyle: { margin: "0px 100px" },
                                attrs: { id: "preview" }
                              },
                              [
                                _vm.url
                                  ? _c("img", {
                                      staticStyle: {
                                        width: "300px",
                                        float: "right"
                                      },
                                      attrs: { src: _vm.url }
                                    })
                                  : _vm._e()
                              ]
                            )
                          ])
                        ],
                        1
                      )
                    ],
                    1
                  ),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "vx-col w-full" },
                    [
                      _c(
                        "vx-card",
                        {
                          staticClass: "mt-3",
                          attrs: { title: "Gallery Images" }
                        },
                        [
                          _c(
                            "vs-button",
                            {
                              staticStyle: { float: "right" },
                              on: { click: _vm.resetGallery }
                            },
                            [_vm._v("Reset")]
                          ),
                          _vm._v(" "),
                          _c(
                            "vs-row",
                            [
                              _c("div", { staticClass: "vs-col" }, [
                                _c(
                                  "div",
                                  {
                                    staticClass: "con-input-upload",
                                    staticStyle: {
                                      float: "unset",
                                      width: "100% !important"
                                    }
                                  },
                                  [
                                    _c("input", {
                                      attrs: {
                                        type: "file",
                                        id: "galleryImage",
                                        multiple: ""
                                      },
                                      on: { change: _vm.uploadImage }
                                    }),
                                    _c("span", { staticClass: "text-input" }, [
                                      _vm._v(" Upload File ")
                                    ]),
                                    _c("span", {
                                      staticClass: "input-progress",
                                      staticStyle: { width: "0%" }
                                    }),
                                    _c(
                                      "button",
                                      {
                                        staticClass:
                                          "btn-upload-all vs-upload--button-upload",
                                        attrs: {
                                          disabled: "disabled",
                                          type: "button",
                                          title: "Upload"
                                        }
                                      },
                                      [
                                        _c(
                                          "i",
                                          {
                                            staticClass:
                                              "material-icons notranslate",
                                            attrs: { translate: "translate" }
                                          },
                                          [_vm._v(" cloud_upload ")]
                                        )
                                      ]
                                    )
                                  ]
                                )
                              ]),
                              _vm._v(" "),
                              _vm._l(_vm.images, function(image, key) {
                                return _c(
                                  "div",
                                  { key: key, staticClass: "vs-col" },
                                  [
                                    _c("div", [
                                      _c("img", {
                                        ref: "image",
                                        refInFor: true,
                                        staticClass: "preview",
                                        staticStyle: { width: "20%" }
                                      }),
                                      _vm._v(
                                        "\n                                " +
                                          _vm._s(image.name) +
                                          "\n                            "
                                      )
                                    ])
                                  ]
                                )
                              })
                            ],
                            2
                          )
                        ],
                        1
                      )
                    ],
                    1
                  )
                ])
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Policies",
                icon: "feather icon-image",
                "before-change": _vm.validateStep6
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-6" } }, [
                _c(
                  "div",
                  { staticClass: "vx-row" },
                  [
                    _c(
                      "div",
                      {
                        staticClass: "px-8",
                        staticStyle: {
                          height: "220px",
                          width: "100%",
                          border: "1px solid #ccc",
                          font: "16px/26px Georgia, Garamond, Serif",
                          overflow: "auto"
                        }
                      },
                      [
                        _vm._l(_vm.policyContent, function(item, index) {
                          return _c("div", {
                            key: index,
                            domProps: { innerHTML: _vm._s(item.content) }
                          })
                        }),
                        _vm._v(" "),
                        _c("br")
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _c("br"),
                    _vm._v(" "),
                    _c(
                      "vs-checkbox",
                      {
                        attrs: { "vs-value": "1" },
                        model: {
                          value: _vm.policy,
                          callback: function($$v) {
                            _vm.policy = $$v
                          },
                          expression: "policy"
                        }
                      },
                      [_vm._v("I agree with your terms and condition.")]
                    )
                  ],
                  1
                )
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "tab-content",
            {
              staticClass: "mb-5",
              attrs: {
                title: "Agreement",
                icon: "feather icon-image",
                "before-change": _vm.validateStep7
              }
            },
            [
              _c("form", { attrs: { "data-vv-scope": "step-7" } }, [
                _c(
                  "div",
                  { staticClass: "vx-row" },
                  [
                    _c(
                      "vx-card",
                      {
                        attrs: {
                          title:
                            "Upload Agreement Scanned Copies - Id Proof, Electricity Bill, Water Bill, Phone Bill, Rent Aggreement"
                        }
                      },
                      [
                        _c("vs-upload", {
                          attrs: { multiple: "", text: "Upload Multiple" }
                        })
                      ],
                      1
                    )
                  ],
                  1
                )
              ])
            ]
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        {
          staticClass: "row",
          staticStyle: { display: "none", padding: "50px" },
          attrs: { id: "SuccessDone" }
        },
        [
          _c(
            "div",
            {
              staticClass: "col-md-12",
              staticStyle: { "text-align": "center" }
            },
            [
              _c("h3", [_vm._v("Your Request has been sent to Admin")]),
              _vm._v(" "),
              _c(
                "vs-button",
                {
                  staticClass: "mt-4",
                  attrs: { color: "success" },
                  on: { click: _vm.gotoList }
                },
                [_vm._v("Go to List")]
              )
            ],
            1
          )
        ]
      )
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/property/add.vue":
/*!*************************************************!*\
  !*** ./resources/js/src/views/property/add.vue ***!
  \*************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _add_vue_vue_type_template_id_1629bbf1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./add.vue?vue&type=template&id=1629bbf1& */ "./resources/js/src/views/property/add.vue?vue&type=template&id=1629bbf1&");
/* harmony import */ var _add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./add.vue?vue&type=script&lang=js& */ "./resources/js/src/views/property/add.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _add_vue_vue_type_template_id_1629bbf1___WEBPACK_IMPORTED_MODULE_0__["render"],
  _add_vue_vue_type_template_id_1629bbf1___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/property/add.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/property/add.vue?vue&type=script&lang=js&":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/property/add.vue?vue&type=script&lang=js& ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./add.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/add.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/property/add.vue?vue&type=template&id=1629bbf1&":
/*!********************************************************************************!*\
  !*** ./resources/js/src/views/property/add.vue?vue&type=template&id=1629bbf1& ***!
  \********************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_1629bbf1___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./add.vue?vue&type=template&id=1629bbf1& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/add.vue?vue&type=template&id=1629bbf1&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_1629bbf1___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_add_vue_vue_type_template_id_1629bbf1___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);