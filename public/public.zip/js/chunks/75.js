(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[75],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TabsDefault_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TabsDefault.vue */ "./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue");
/* harmony import */ var _TabsColor_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TabsColor.vue */ "./resources/js/src/views/components/vuesax/tabs/TabsColor.vue");
/* harmony import */ var _TabsAlignments_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./TabsAlignments.vue */ "./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue");
/* harmony import */ var _TabsPosition_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./TabsPosition.vue */ "./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue");
/* harmony import */ var _TabsIcons_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./TabsIcons.vue */ "./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    TabsDefault: _TabsDefault_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    TabsColor: _TabsColor_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    TabsAlignments: _TabsAlignments_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    TabsPosition: _TabsPosition_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    TabsIcons: _TabsIcons_vue__WEBPACK_IMPORTED_MODULE_4__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      colorx: 'success'
    };
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=template&id=28147c23&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=template&id=28147c23& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "tabs-demo" } },
    [
      _c("tabs-default"),
      _vm._v(" "),
      _c("tabs-color"),
      _vm._v(" "),
      _c("tabs-alignments"),
      _vm._v(" "),
      _c("tabs-position"),
      _vm._v(" "),
      _c("tabs-icons")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue?vue&type=template&id=1c8eb973&":
/*!***************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue?vue&type=template&id=1c8eb973& ***!
  \***************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Alignments", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "Change the alignment of the buttons with the property alignments. Allowed values are:"
        )
      ]),
      _vm._v(" "),
      _c("vx-list", {
        staticClass: "mt-3",
        attrs: { list: ["center", "right", "fixed"] }
      }),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c("h6", { staticClass: "mb-3" }, [_vm._v(" Default ")]),
          _vm._v(" "),
          _c(
            "vs-tabs",
            [
              _c("vs-tab", { attrs: { label: "Home" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Documents" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Contributors" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Ecosystem" } }, [_c("div")])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c("h6", { staticClass: "mb-3" }, [_vm._v(" Center ")]),
          _vm._v(" "),
          _c(
            "vs-tabs",
            { attrs: { alignment: "center" } },
            [
              _c("vs-tab", { attrs: { label: "Home" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Documents" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Contributors" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Ecosystem" } }, [_c("div")])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c("h6", { staticClass: "mb-3" }, [_vm._v(" Right ")]),
          _vm._v(" "),
          _c(
            "vs-tabs",
            { attrs: { alignment: "right" } },
            [
              _c("vs-tab", { attrs: { label: "Home" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Documents" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Contributors" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Ecosystem" } }, [_c("div")])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c("h6", { staticClass: "mb-3" }, [_vm._v(" Fixed ")]),
          _vm._v(" "),
          _c(
            "vs-tabs",
            { attrs: { alignment: "fixed" } },
            [
              _c("vs-tab", { attrs: { label: "Home" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Documents" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Contributors" } }, [_c("div")]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Ecosystem" } }, [_c("div")])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <div class="mt-5">\n    <h3> Default </h3>\n    <vs-tabs>\n      <vs-tab label="Home">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Documents">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Contributors">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Ecosystem">\n        <div></div>\n      </vs-tab>\n    </vs-tabs>\n  </div>\n\n  <div class="mt-5">\n    <h3> Center </h3>\n    <vs-tabs alignment="center">\n      <vs-tab label="Home">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Documents">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Contributors">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Ecosystem">\n        <div></div>\n      </vs-tab>\n    </vs-tabs>\n  </div>\n\n  <div class="mt-5">\n    <h3> Right </h3>\n    <vs-tabs alignment="right">\n      <vs-tab label="Home">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Documents">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Contributors">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Ecosystem">\n        <div></div>\n      </vs-tab>\n    </vs-tabs>\n  </div>\n\n  <div class="mt-5">\n    <h3> Fixed </h3>\n    <vs-tabs alignment="fixed">\n      <vs-tab label="Home">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Documents">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Contributors">\n        <div></div>\n      </vs-tab>\n      <vs-tab label="Ecosystem">\n        <div></div>\n      </vs-tab>\n    </vs-tabs>\n  </div>\n</template>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=template&id=26dd0db0&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=template&id=26dd0db0& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Color", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can change the color of the component with the property color, the parameter allows the main colors and HEX or RGB"
        )
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { icon: "warning", active: "true", color: "warning" }
        },
        [
          _c("span", [
            _vm._v("Only "),
            _c("strong", [_vm._v("RGB")]),
            _vm._v(" and "),
            _c("strong", [_vm._v("HEX")]),
            _vm._v(" colors are supported.")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-tabs",
            { attrs: { color: _vm.colorx } },
            [
              _c(
                "vs-tab",
                {
                  attrs: { label: "Success" },
                  on: {
                    click: function($event) {
                      _vm.colorx = "success"
                    }
                  }
                },
                [
                  _c("div", { staticClass: "con-tab-ejemplo" }, [
                    _c("p", [
                      _vm._v(
                        "Muffin cupcake candy chocolate cake gummi bears fruitcake donut dessert pie. Wafer toffee bonbon dragée. Jujubes cotton candy gummies chupa chups. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Candy cookie sweet roll bear claw sweet roll. Cake tiramisu cotton candy gingerbread cheesecake toffee cake. Cookie liquorice dessert candy canes jelly."
                      )
                    ]),
                    _vm._v(" "),
                    _c("p", { staticClass: "mt-2" }, [
                      _vm._v(
                        "Sweet chocolate muffin fruitcake gummies jujubes pie lollipop. Brownie marshmallow caramels gingerbread jelly beans chocolate bar oat cake wafer. Chocolate bar danish icing sweet apple pie jelly-o carrot cake cookie cake. "
                      )
                    ])
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                {
                  attrs: { label: "Danger" },
                  on: {
                    click: function($event) {
                      _vm.colorx = "danger"
                    }
                  }
                },
                [
                  _c("div", { staticClass: "con-tab-ejemplo" }, [
                    _c("p", [
                      _vm._v(
                        "Biscuit macaroon sugar plum sesame snaps oat cake halvah fruitcake pudding cotton candy. Cheesecake tart wafer soufflé. Chocolate marzipan donut pie soufflé dragée cheesecake. Gummi bears dessert croissant chocolate jujubes fruitcake. Pie cupcake halvah. "
                      )
                    ]),
                    _vm._v(" "),
                    _c("p", { staticClass: "mt-2" }, [
                      _vm._v(
                        "Tiramisu carrot cake marzipan sugar plum powder marzipan sugar plum bonbon powder. Macaroon jujubes ice cream sugar plum lollipop wafer caramels. Cheesecake chocolate tart cake gingerbread fruitcake cake candy jelly-o. Candy cookie lollipop. Wafer lemon drops chocolate cake gummi bears."
                      )
                    ])
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                {
                  attrs: { label: "Warning" },
                  on: {
                    click: function($event) {
                      _vm.colorx = "warning"
                    }
                  }
                },
                [
                  _c("div", { staticClass: "con-tab-ejemplo" }, [
                    _c("p", [
                      _vm._v(
                        "Brownie ice cream biscuit candy biscuit jujubes. Dessert cake gummies fruitcake chocolate cake sweet roll pastry croissant danish. Pudding chocolate bar sweet roll muffin cake tootsie roll biscuit pastry. Chupa chups dessert donut. Pastry gummi bears tart cookie apple pie sugar plum bear claw."
                      )
                    ]),
                    _vm._v(" "),
                    _c("p", { staticClass: "mt-2" }, [
                      _vm._v(
                        "Pudding jelly chocolate powder jelly beans icing candy soufflé sweet. Cotton candy sugar plum fruitcake dessert dragée. Toffee chocolate cake chocolate cake oat cake topping macaroon caramels cotton candy. Ice cream lemon drops lollipop."
                      )
                    ])
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                {
                  attrs: { label: "Dark" },
                  on: {
                    click: function($event) {
                      _vm.colorx = "dark"
                    }
                  }
                },
                [
                  _c("div", { staticClass: "con-tab-ejemplo" }, [
                    _c("p", [
                      _vm._v(
                        "Chocolate powder candy canes cake gummies tart donut. Gummi bears sesame snaps bonbon apple pie carrot cake croissant marzipan candy canes jelly-o. Marshmallow sweet cake gummies ice cream toffee. Jelly gingerbread jelly beans tart tart. Jelly-o bonbon jelly-o lemon drops sweet roll jujubes cake. Chocolate cake dessert sugar plum."
                      )
                    ]),
                    _vm._v(" "),
                    _c("p", { staticClass: "mt-2" }, [
                      _vm._v(
                        "Jelly beans brownie chocolate bar. Jujubes lemon drops apple pie chocolate cake bear claw cupcake chocolate sweet pastry. Pastry carrot cake liquorice. Sesame snaps sugar plum chupa chups tiramisu. Halvah cake chocolate bar jelly beans dragée chocolate halvah pudding pudding."
                      )
                    ])
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                {
                  attrs: { label: "RGB | HEX" },
                  on: {
                    click: function($event) {
                      _vm.colorx = "rgb(16, 233, 179)"
                    }
                  }
                },
                [
                  _c("div", { staticClass: "con-tab-ejemplo" }, [
                    _c("p", [
                      _vm._v(
                        "Gingerbread tart marzipan sweet lemon drops wafer soufflé apple pie lemon drops. Cake pie apple pie icing fruitcake liquorice dessert sugar plum liquorice. Cake liquorice sugar plum cake croissant sweet. Jelly beans donut dessert. Cake jelly-o marzipan candy canes biscuit jelly toffee. Gummi bears jelly-o pastry macaroon gummies gingerbread liquorice bonbon chocolate cake."
                      )
                    ]),
                    _vm._v(" "),
                    _c("p", { staticClass: "mt-2" }, [
                      _vm._v(
                        "Dragée muffin lemon drops. Cake sweet tootsie roll cupcake cake sugar plum lemon drops. Pudding gingerbread sesame snaps sweet. Gummi bears gingerbread pastry cotton candy sesame snaps toffee. Cake chocolate bonbon marzipan jelly-o powder. Cupcake jujubes fruitcake oat cake powder caramels."
                      )
                    ])
                  ])
                ]
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <vs-tabs :color="colorx">\n    <vs-tab @click="colorx = \'success\'" label="Success">\n      <div class="con-tab-ejemplo">\n      <span>Jujubes ....</span></div>\n    </vs-tab>\n\n    <vs-tab @click="colorx = \'danger\'" label="Danger">\n      <div class="con-tab-ejemplo">\n      <span>Halvah ...</span></div>\n    </vs-tab>\n\n    <vs-tab @click="colorx = \'warning\'" label="Warning">\n      <div class="con-tab-ejemplo">\n      <span>Chocolate ....</span></div>\n    </vs-tab>\n\n    <vs-tab @click="colorx = \'dark\'" label="Dark">\n      <div class="con-tab-ejemplo">\n      <span>Macaroon ....</span></div>\n    </vs-tab>\n\n    <vs-tab @click="colorx = \'rgb(16, 233, 179)\'" label="RGB | HEX">\n      <div class="con-tab-ejemplo">\n      <span>Cupcake ....</span></div>\n    </vs-tab>\n  </vs-tabs>\n</template>\n\n<script>\nexport default {\n  data:()=>({\n    colorx:\'success\'\n  }),\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue?vue&type=template&id=63a2c764&":
/*!************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue?vue&type=template&id=63a2c764& ***!
  \************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Default", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("To implement a tabs, use the "),
        _c("code", [_vm._v("vs-tabs")]),
        _vm._v(" component. It must include "),
        _c("code", [_vm._v("vs-tab")]),
        _vm._v(" child components that represent each tab")
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v("For the title of each tab the "),
            _c("code", [_vm._v("label")]),
            _vm._v(" property is implemented in the "),
            _c("code", [_vm._v("vs-tab")]),
            _vm._v(" component")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-tabs",
            [
              _c("vs-tab", { attrs: { label: "Home" } }, [
                _c("div", { staticClass: "tab-text" }, [
                  _c("p", [
                    _vm._v(
                      "Muffin cupcake candy chocolate cake gummi bears fruitcake donut dessert pie. Wafer toffee bonbon dragée. Jujubes cotton candy gummies chupa chups. Sweet fruitcake cheesecake biscuit cotton candy. Cookie powder marshmallow donut. Candy cookie sweet roll bear claw sweet roll. Cake tiramisu cotton candy gingerbread cheesecake toffee cake. Cookie liquorice dessert candy canes jelly."
                    )
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "mt-2" }, [
                    _vm._v(
                      "Sweet chocolate muffin fruitcake gummies jujubes pie lollipop. Brownie marshmallow caramels gingerbread jelly beans chocolate bar oat cake wafer. Chocolate bar danish icing sweet apple pie jelly-o carrot cake cookie cake. "
                    )
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Service" } }, [
                _c("div", { staticClass: "tab-text" }, [
                  _c("p", [
                    _vm._v(
                      "Biscuit macaroon sugar plum sesame snaps oat cake halvah fruitcake pudding cotton candy. Cheesecake tart wafer soufflé. Chocolate marzipan donut pie soufflé dragée cheesecake. Gummi bears dessert croissant chocolate jujubes fruitcake. Pie cupcake halvah. "
                    )
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "mt-2" }, [
                    _vm._v(
                      "Tiramisu carrot cake marzipan sugar plum powder marzipan sugar plum bonbon powder. Macaroon jujubes ice cream sugar plum lollipop wafer caramels. Cheesecake chocolate tart cake gingerbread fruitcake cake candy jelly-o. Candy cookie lollipop. Wafer lemon drops chocolate cake gummi bears."
                    )
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "login" } }, [
                _c("div", { staticClass: "tab-text" }, [
                  _c("p", [
                    _vm._v(
                      "Brownie ice cream biscuit candy biscuit jujubes. Dessert cake gummies fruitcake chocolate cake sweet roll pastry croissant danish. Pudding chocolate bar sweet roll muffin cake tootsie roll biscuit pastry. Chupa chups dessert donut. Pastry gummi bears tart cookie apple pie sugar plum bear claw."
                    )
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "mt-2" }, [
                    _vm._v(
                      "Pudding jelly chocolate powder jelly beans icing candy soufflé sweet. Cotton candy sugar plum fruitcake dessert dragée. Toffee chocolate cake chocolate cake oat cake topping macaroon caramels cotton candy. Ice cream lemon drops lollipop."
                    )
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { disabled: "", label: "Disabled" } }, [
                _c("div", { staticClass: "tab-text" }, [
                  _c("p", [
                    _vm._v(
                      "Chocolate powder candy canes cake gummies tart donut. Gummi bears sesame snaps bonbon apple pie carrot cake croissant marzipan candy canes jelly-o. Marshmallow sweet cake gummies ice cream toffee. Jelly gingerbread jelly beans tart tart. Jelly-o bonbon jelly-o lemon drops sweet roll jujubes cake. Chocolate cake dessert sugar plum."
                    )
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "mt-2" }, [
                    _vm._v(
                      "Jelly beans brownie chocolate bar. Jujubes lemon drops apple pie chocolate cake bear claw cupcake chocolate sweet pastry. Pastry carrot cake liquorice. Sesame snaps sugar plum chupa chups tiramisu. Halvah cake chocolate bar jelly beans dragée chocolate halvah pudding pudding."
                    )
                  ])
                ])
              ]),
              _vm._v(" "),
              _c("vs-tab", { attrs: { label: "Account" } }, [
                _c("div", { staticClass: "tab-text" }, [
                  _c("p", [
                    _vm._v(
                      "Gingerbread tart marzipan sweet lemon drops wafer soufflé apple pie lemon drops. Cake pie apple pie icing fruitcake liquorice dessert sugar plum liquorice. Cake liquorice sugar plum cake croissant sweet. Jelly beans donut dessert. Cake jelly-o marzipan candy canes biscuit jelly toffee. Gummi bears jelly-o pastry macaroon gummies gingerbread liquorice bonbon chocolate cake."
                    )
                  ]),
                  _vm._v(" "),
                  _c("p", { staticClass: "mt-2" }, [
                    _vm._v(
                      "Dragée muffin lemon drops. Cake sweet tootsie roll cupcake cake sugar plum lemon drops. Pudding gingerbread sesame snaps sweet. Gummi bears gingerbread pastry cotton candy sesame snaps toffee. Cake chocolate bonbon marzipan jelly-o powder. Cupcake jujubes fruitcake oat cake powder caramels."
                    )
                  ])
                ])
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<vs-tabs>\n  <vs-tab label="Home">\n    <div class="tab-text">\n      <span>Jujubes ....</span>\n    </div>\n  </vs-tab>\n  <vs-tab label="Service">\n    <div class="tab-text">\n      <span>Halvah ...</span>\n    </div>\n  </vs-tab>\n  <vs-tab label="login">\n    <div class="tab-text">\n      <span>Chocolate ....</span>\n    </div>\n  </vs-tab>\n  <vs-tab disabled label="Disabled">\n    <div class="tab-text">\n      <span>Macaroon ....</span>\n    </div>\n  </vs-tab>\n  <vs-tab label="Account">\n    <div class="tab-text">\n      <span>Cupcake ....</span>\n    </div>\n  </vs-tab>\n</vs-tabs>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue?vue&type=template&id=5ef57de7&":
/*!**********************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue?vue&type=template&id=5ef57de7& ***!
  \**********************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Icons", "code-toggler": "" } },
    [
      _c(
        "vs-tabs",
        [
          _c("vs-tab", {
            attrs: { label: "Home", "icon-pack": "feather", icon: "icon-home" }
          }),
          _vm._v(" "),
          _c("vs-tab", {
            attrs: { label: "Box", "icon-pack": "feather", icon: "icon-box" }
          }),
          _vm._v(" "),
          _c("vs-tab", {
            attrs: { label: "Mail", "icon-pack": "feather", icon: "icon-mail" }
          }),
          _vm._v(" "),
          _c("vs-tab", {
            attrs: {
              label: "Heart",
              "icon-pack": "feather",
              icon: "icon-heart"
            }
          })
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template lang="html">\n  <vs-tabs>\n    <vs-tab label="Home" icon-pack="feather" icon="icon-home">\n    </vs-tab>\n    <vs-tab label="Box" icon-pack="feather" icon="icon-box">\n    </vs-tab>\n    <vs-tab label="Mail" icon-pack="feather" icon="icon-mail">\n    </vs-tab>\n    <vs-tab label="Heart" icon-pack="feather" icon="icon-heart">\n    </vs-tab>\n  </vs-tabs>\n</template>\n    '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue?vue&type=template&id=230ef1ec&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue?vue&type=template&id=230ef1ec& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Position", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can change the position of the menu with the property "),
        _c("code", [_vm._v("position")]),
        _vm._v(" that as a value you can have: "),
        _c("code", [_vm._v("top")]),
        _vm._v(", "),
        _c("code", [_vm._v("right")]),
        _vm._v(", "),
        _c("code", [_vm._v("bottom")]),
        _vm._v(", "),
        _c("code", [_vm._v("left")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v("For the title of each tab the "),
            _c("code", [_vm._v("label")]),
            _vm._v(" property is implemented in the "),
            _c("code", [_vm._v("vs-tab")]),
            _vm._v(" component")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5" },
        [
          _c(
            "vs-tabs",
            { attrs: { color: "rgb(32, 201, 192)" } },
            [
              _c(
                "vs-tab",
                { attrs: { label: "Top" } },
                [
                  _c(
                    "vs-tabs",
                    { attrs: { color: "rgb(201, 32, 178)" } },
                    [
                      _c("vs-tab", { attrs: { label: "Home" } }, [
                        _c("span", [
                          _vm._v(
                            "Jujubes gingerbread cake pastry biscuit jelly-o marshmallow. Chocolate cake jelly marshmallow topping. Danish caramels gummies tootsie roll marshmallow sweet croissant."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "Service" } }, [
                        _c("span", [
                          _vm._v(
                            "Halvah dessert fruitcake toffee oat cake tart oat cake topping jelly beans. Pudding sweet pie pastry lemon drops jujubes danish pie gingerbread. Liquorice powder wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "login" } }, [
                        _c("span", [
                          _vm._v(
                            "Chocolate icing pie danish gummies. Dragée gummies toffee muffin chocolate bar marshmallow. Marshmallow chupa chups muffin cake icing pastry wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c(
                        "vs-tab",
                        { attrs: { disabled: "", label: "Disabled" } },
                        [
                          _c("span", [
                            _vm._v(
                              "Macaroon icing lemon drops jelly-o. Bonbon pie tart chocolate bar pastry. Sugar plum bonbon candy canes dragée toffee dragée toffee."
                            )
                          ])
                        ]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                { attrs: { label: "Right" } },
                [
                  _c(
                    "vs-tabs",
                    { attrs: { position: "right", color: "rgb(29, 55, 194)" } },
                    [
                      _c("vs-tab", { attrs: { label: "Home" } }, [
                        _c("span", [
                          _vm._v(
                            "Jujubes gingerbread cake pastry biscuit jelly-o marshmallow. Chocolate cake jelly marshmallow topping. Danish caramels gummies tootsie roll marshmallow sweet croissant."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "Service" } }, [
                        _c("span", [
                          _vm._v(
                            "Halvah dessert fruitcake toffee oat cake tart oat cake topping jelly beans. Pudding sweet pie pastry lemon drops jujubes danish pie gingerbread. Liquorice powder wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "login" } }, [
                        _c("span", [
                          _vm._v(
                            "Chocolate icing pie danish gummies. Dragée gummies toffee muffin chocolate bar marshmallow. Marshmallow chupa chups muffin cake icing pastry wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c(
                        "vs-tab",
                        { attrs: { disabled: "", label: "Disabled" } },
                        [
                          _c("span", [
                            _vm._v(
                              "Macaroon icing lemon drops jelly-o. Bonbon pie tart chocolate bar pastry. Sugar plum bonbon candy canes dragée toffee dragée toffee."
                            )
                          ])
                        ]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                { attrs: { label: "Bottom" } },
                [
                  _c(
                    "vs-tabs",
                    {
                      attrs: { position: "bottom", color: "rgb(29, 55, 194)" }
                    },
                    [
                      _c("vs-tab", { attrs: { label: "Home" } }, [
                        _c("span", [
                          _vm._v(
                            "Jujubes gingerbread cake pastry biscuit jelly-o marshmallow. Chocolate cake jelly marshmallow topping. Danish caramels gummies tootsie roll marshmallow sweet croissant."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "Service" } }, [
                        _c("span", [
                          _vm._v(
                            "Halvah dessert fruitcake toffee oat cake tart oat cake topping jelly beans. Pudding sweet pie pastry lemon drops jujubes danish pie gingerbread. Liquorice powder wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "login" } }, [
                        _c("span", [
                          _vm._v(
                            "Chocolate icing pie danish gummies. Dragée gummies toffee muffin chocolate bar marshmallow. Marshmallow chupa chups muffin cake icing pastry wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c(
                        "vs-tab",
                        { attrs: { disabled: true, label: "Disabled" } },
                        [
                          _c("span", [
                            _vm._v(
                              "Macaroon icing lemon drops jelly-o. Bonbon pie tart chocolate bar pastry. Sugar plum bonbon candy canes dragée toffee dragée toffee."
                            )
                          ])
                        ]
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-tab",
                { attrs: { label: "Left" } },
                [
                  _c(
                    "vs-tabs",
                    { attrs: { position: "left", color: "danger" } },
                    [
                      _c("vs-tab", { attrs: { label: "Home" } }, [
                        _c("span", [
                          _vm._v(
                            "Jujubes gingerbread cake pastry biscuit jelly-o marshmallow. Chocolate cake jelly marshmallow topping. Danish caramels gummies tootsie roll marshmallow sweet croissant."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "Service" } }, [
                        _c("span", [
                          _vm._v(
                            "Halvah dessert fruitcake toffee oat cake tart oat cake topping jelly beans. Pudding sweet pie pastry lemon drops jujubes danish pie gingerbread. Liquorice powder wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c("vs-tab", { attrs: { label: "login" } }, [
                        _c("span", [
                          _vm._v(
                            "Chocolate icing pie danish gummies. Dragée gummies toffee muffin chocolate bar marshmallow. Marshmallow chupa chups muffin cake icing pastry wafer."
                          )
                        ])
                      ]),
                      _vm._v(" "),
                      _c(
                        "vs-tab",
                        { attrs: { disabled: true, label: "Disabled" } },
                        [
                          _c("span", [
                            _vm._v(
                              "Macaroon icing lemon drops jelly-o. Bonbon pie tart chocolate bar pastry. Sugar plum bonbon candy canes dragée toffee dragée toffee."
                            )
                          ])
                        ]
                      )
                    ],
                    1
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <div>\n    <vs-tabs color="rgb(32, 201, 192)">\n\n      <vs-tab label="Top">\n        <!-- top -->\n        <vs-tabs color="rgb(201, 32, 178)">\n          <vs-tab label="Home">\n            <span>Jujubes ....</span>\n          </vs-tab>\n          <vs-tab label="Service">\n            <span>Halvah ....</span>\n          </vs-tab>\n          <vs-tab label="login">\n            <span>Chocolate .....</span>\n          </vs-tab>\n          <vs-tab disabled label="Disabled">\n            <span>Macaroon ......</span>\n          </vs-tab>\n        </vs-tabs>\n      </vs-tab>\n\n      <vs-tab label="Right">\n        <!-- right -->\n        <vs-tabs position="right" color="rgb(29, 55, 194)">\n          <vs-tab label="Home">\n            <span>Jujubes ....</span>\n          </vs-tab>\n          <vs-tab label="Service">\n            <span>Halvah ....</span>\n          </vs-tab>\n          <vs-tab label="login">\n            <span>Chocolate .....</span>\n          </vs-tab>\n          <vs-tab disabled label="Disabled">\n            <span>Macaroon ......</span>\n          </vs-tab>\n        </vs-tabs>\n      </vs-tab>\n\n      <vs-tab label="Bottom">\n        <!-- bottom -->\n        <vs-tabs position="bottom" color="rgb(29, 55, 194)">\n          <vs-tab label="Home">\n            <span>Jujubes ....</span>\n          </vs-tab>\n          <vs-tab label="Service">\n            <span>Halvah ....</span>\n          </vs-tab>\n          <vs-tab label="login">\n            <span>Chocolate .....</span>\n          </vs-tab>\n          <vs-tab :disabled="true" label="Disabled">\n            <div>Macaroon .....</div>\n          </vs-tab>\n        </vs-tabs>\n      </vs-tab>\n\n      <vs-tab label="Left">\n        <!-- left -->\n        <vs-tabs position="left" color="danger">\n          <vs-tab label="Home">\n            <span>Jujubes ....</span>\n          </vs-tab>\n          <vs-tab label="Service">\n            <span>Halvah ....</span>\n          </vs-tab>\n          <vs-tab label="login">\n            <span>Chocolate .....</span>\n          </vs-tab>\n          <vs-tab :disabled="true" label="Disabled">\n            <div>Macaroon .....</div>\n          </vs-tab>\n        </vs-tabs>\n      </vs-tab>\n    </vs-tabs>\n  </div>\n</template>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/Tabs.vue":
/*!****************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/Tabs.vue ***!
  \****************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Tabs_vue_vue_type_template_id_28147c23___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Tabs.vue?vue&type=template&id=28147c23& */ "./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=template&id=28147c23&");
/* harmony import */ var _Tabs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Tabs.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _Tabs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Tabs_vue_vue_type_template_id_28147c23___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Tabs_vue_vue_type_template_id_28147c23___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/tabs/Tabs.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=script&lang=js&":
/*!*****************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Tabs.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=template&id=28147c23&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=template&id=28147c23& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_template_id_28147c23___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Tabs.vue?vue&type=template&id=28147c23& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/Tabs.vue?vue&type=template&id=28147c23&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_template_id_28147c23___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Tabs_vue_vue_type_template_id_28147c23___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue":
/*!**************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TabsAlignments_vue_vue_type_template_id_1c8eb973___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TabsAlignments.vue?vue&type=template&id=1c8eb973& */ "./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue?vue&type=template&id=1c8eb973&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _TabsAlignments_vue_vue_type_template_id_1c8eb973___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TabsAlignments_vue_vue_type_template_id_1c8eb973___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue?vue&type=template&id=1c8eb973&":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue?vue&type=template&id=1c8eb973& ***!
  \*********************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsAlignments_vue_vue_type_template_id_1c8eb973___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TabsAlignments.vue?vue&type=template&id=1c8eb973& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsAlignments.vue?vue&type=template&id=1c8eb973&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsAlignments_vue_vue_type_template_id_1c8eb973___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsAlignments_vue_vue_type_template_id_1c8eb973___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsColor.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsColor.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TabsColor_vue_vue_type_template_id_26dd0db0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TabsColor.vue?vue&type=template&id=26dd0db0& */ "./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=template&id=26dd0db0&");
/* harmony import */ var _TabsColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./TabsColor.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _TabsColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _TabsColor_vue_vue_type_template_id_26dd0db0___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TabsColor_vue_vue_type_template_id_26dd0db0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/tabs/TabsColor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TabsColor.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=template&id=26dd0db0&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=template&id=26dd0db0& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsColor_vue_vue_type_template_id_26dd0db0___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TabsColor.vue?vue&type=template&id=26dd0db0& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsColor.vue?vue&type=template&id=26dd0db0&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsColor_vue_vue_type_template_id_26dd0db0___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsColor_vue_vue_type_template_id_26dd0db0___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue":
/*!***********************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue ***!
  \***********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TabsDefault_vue_vue_type_template_id_63a2c764___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TabsDefault.vue?vue&type=template&id=63a2c764& */ "./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue?vue&type=template&id=63a2c764&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _TabsDefault_vue_vue_type_template_id_63a2c764___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TabsDefault_vue_vue_type_template_id_63a2c764___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/tabs/TabsDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue?vue&type=template&id=63a2c764&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue?vue&type=template&id=63a2c764& ***!
  \******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsDefault_vue_vue_type_template_id_63a2c764___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TabsDefault.vue?vue&type=template&id=63a2c764& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsDefault.vue?vue&type=template&id=63a2c764&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsDefault_vue_vue_type_template_id_63a2c764___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsDefault_vue_vue_type_template_id_63a2c764___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue":
/*!*********************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TabsIcons_vue_vue_type_template_id_5ef57de7___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TabsIcons.vue?vue&type=template&id=5ef57de7& */ "./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue?vue&type=template&id=5ef57de7&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _TabsIcons_vue_vue_type_template_id_5ef57de7___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TabsIcons_vue_vue_type_template_id_5ef57de7___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/tabs/TabsIcons.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue?vue&type=template&id=5ef57de7&":
/*!****************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue?vue&type=template&id=5ef57de7& ***!
  \****************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsIcons_vue_vue_type_template_id_5ef57de7___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TabsIcons.vue?vue&type=template&id=5ef57de7& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsIcons.vue?vue&type=template&id=5ef57de7&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsIcons_vue_vue_type_template_id_5ef57de7___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsIcons_vue_vue_type_template_id_5ef57de7___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _TabsPosition_vue_vue_type_template_id_230ef1ec___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./TabsPosition.vue?vue&type=template&id=230ef1ec& */ "./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue?vue&type=template&id=230ef1ec&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _TabsPosition_vue_vue_type_template_id_230ef1ec___WEBPACK_IMPORTED_MODULE_0__["render"],
  _TabsPosition_vue_vue_type_template_id_230ef1ec___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/tabs/TabsPosition.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue?vue&type=template&id=230ef1ec&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue?vue&type=template&id=230ef1ec& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsPosition_vue_vue_type_template_id_230ef1ec___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./TabsPosition.vue?vue&type=template&id=230ef1ec& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/tabs/TabsPosition.vue?vue&type=template&id=230ef1ec&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsPosition_vue_vue_type_template_id_230ef1ec___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_TabsPosition_vue_vue_type_template_id_230ef1ec___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);