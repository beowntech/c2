(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[131],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/update.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/property/update.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! axios */ "./node_modules/axios/index.js");
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! jquery */ "./node_modules/jquery/dist/jquery.js");
/* harmony import */ var jquery__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(jquery__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var vue_form_wizard__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! vue-form-wizard */ "./node_modules/vue-form-wizard/dist/vue-form-wizard.js");
/* harmony import */ var vue_form_wizard__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(vue_form_wizard__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! vue-select */ "./node_modules/vue-select/dist/vue-select.js");
/* harmony import */ var vue_select__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(vue_select__WEBPACK_IMPORTED_MODULE_3__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//




/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      amenities: [],
      amenitiesValue: [],
      classes: ['danger', 'primary', 'success', 'rgb(32, 201, 192)'],
      number: 0,
      property_name: "",
      email: "",
      parkingSelect: "1",
      propSize: "",
      village: "",
      policy: "",
      district: "",
      roadName: "",
      images: [],
      selectedFiles: [],
      pinCode: "",
      citySelect: "",
      stateSelect: "",
      RoomLength: "",
      RoomBreadth: "",
      roomName: "",
      beds: "",
      noofbeds: "",
      addressValue: "",
      maximum_guest: "",
      attach_bathroom: "",
      selectedFeatured: null,
      selectedCategory: "",
      EmailEnter: "",
      Hotel: "",
      Language: "",
      extra_bed: "",
      url: null,
      length: "",
      breadth: "",
      textarea: "",
      eventName: "",
      eventLocation: "san-francisco",
      status: "plannning",
      room_card: [],
      managers: [],
      selectedClass: '',
      currPropId: null,
      policyContent: [],
      b2bprice: "",
      roomTypeOptions: [{
        name: 'Premium',
        id: 1
      }, {
        name: 'Deluxe',
        id: 2
      }, {
        name: 'Normal',
        id: 3
      }],
      cityOptions: [{
        name: 'Chopta',
        id: 48357
      }],
      stateOptions: [{
        name: 'Uttarakhand',
        id: 39
      }],
      min: 1,
      max: 3,
      gallery: [],
      managersSelect: null,
      room_type: "",
      bedOptions: [{
        text: "1",
        value: 1
      }, {
        text: "2",
        value: 2
      }, {
        text: "3",
        value: 3
      }, {
        text: "4",
        value: 4
      }],
      maximumGuestOptions: [{
        text: "1",
        value: 1
      }, {
        text: "2",
        value: 2
      }, {
        text: "3",
        value: 3
      }, {
        text: "4",
        value: 4
      }, {
        text: "5",
        value: 5
      }, {
        text: "6",
        value: 6
      }, {
        text: "7",
        value: 7
      }, {
        text: "8",
        value: 8
      }, {
        text: "9",
        value: 9
      }, {
        text: "10",
        value: 10
      }],
      categories: [],
      MealOption: [],
      MealOptionExclude: [],
      prop_data: [],
      bathroomOptions: [{
        text: "Yes",
        value: 1
      }, {
        text: "No",
        value: 0
      }]
    };
  },
  methods: {
    updateBasic: function updateBasic() {
      var _this = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/properties/update/basic', {
        name: this.property_name,
        language: this.language,
        type: Number(this.selectedCategory),
        hotel: Number(this.Hotel),
        email: this.EmailEnter,
        description: this.textarea,
        size: this.propSize,
        parking: Number(this.parkingSelect),
        prop_id: this.$route.params.PropId
      }).then(function (res) {
        console.log(res);

        if (res.data['status'] == 1) {
          _this.alert('Basic Updated Successfully', '', 'success');
        }
      }).catch(function (err) {
        console.log(err);
      });
    },
    getManagers: function getManagers() {
      var _this2 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/users/managers').then(function (res) {
        console.log(res);
        _this2.managers = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getAmen: function getAmen() {
      var _this3 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/amenities/get').then(function (res) {
        console.log(res);
        _this3.amenities = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getCat: function getCat() {
      var _this4 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/categories/getNames').then(function (res) {
        console.log(res);
        _this4.categories = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getState: function getState() {
      var _this5 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/state/get').then(function (res) {
        console.log(res);
        _this5.stateOptions = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getCity: function getCity() {
      var _this6 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/city/get').then(function (res) {
        console.log(res);
        _this6.cityOptions = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    resetGallery: function resetGallery() {
      document.getElementById("galleryImage").value = "";
      this.images = [];
      this.selectedFiles = [];
    },
    deleteUpload: function deleteUpload(event) {
      console.log("Delete:" + JSON.stringify(event));
    },
    createRoom: function createRoom() {
      var room = jquery__WEBPACK_IMPORTED_MODULE_1___default()("#room_card").clone();
      var $div = jquery__WEBPACK_IMPORTED_MODULE_1___default()('.cloneDiv[id^="room_card"]:last'); // Read the Number from that DIV's ID (i.e: 3 from "klon3")
      // And increment that number by 1

      var num = parseInt($div.prop("id").match(/\d+/g), 10) + 1; // Clone it and assign the new ID (i.e: from num 4 to ID "klon4")

      var $klon = $div.clone().prop('id', 'room_card' + num);
      jquery__WEBPACK_IMPORTED_MODULE_1___default()("#copy_room").append($klon);
      jquery__WEBPACK_IMPORTED_MODULE_1___default()("html, body").animate({
        scrollTop: jquery__WEBPACK_IMPORTED_MODULE_1___default()(document).height()
      }, 1000);
    },
    successUpload: function successUpload(event) {
      console.log(event);
    },
    getPolicy: function getPolicy() {
      var _this7 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/policies/get').then(function (res) {
        console.log(res);
        _this7.policyContent = res.data;
      }).catch(function (err) {
        console.log(err);
      });
    },
    getBasic: function getBasic() {
      var _this8 = this;

      axios__WEBPACK_IMPORTED_MODULE_0___default.a.post('/api/properties/getProp', {
        prop_id: this.$route.params.PropId
      }).then(function (res) {
        _this8.property_name = res.data[0].name;
        _this8.textarea = res.data[0].description;
        _this8.selectedCategory = res.data[0].prop[0].name;
        _this8.Language = res.data[0].language;
        _this8.propSize = res.data[0].property_size;
        _this8.Hotel = res.data[0].hotel_contact;
        _this8.parkingSelect = String(res.data[0].parking);
        _this8.EmailEnter = res.data[0].email;
        _this8.addressValue = res.data[0].address;
        _this8.village = res.data[0].village;
        _this8.district = res.data[0].district;
        _this8.roadName = res.data[0].road_name;
        _this8.pinCode = res.data[0].pincode;
        _this8.citySelect = res.data[0].city;
        _this8.stateSelect = res.data[0].state;

        for (var i = 0; i < JSON.parse(res.data[0].amenities).length; i++) {
          _this8.amenitiesValue.push(JSON.parse(res.data[0].amenities)[i]);
        }

        console.log(_this8.amenitiesValue);

        _this8.$vs.loading.close();
      }).catch(function (err) {
        console.log(err);
      });
    },
    removeMeal: function removeMeal() {
      this.MealOption = [];
    },
    removeMealE: function removeMealE() {
      this.MealOptionExclude = [];
    },
    removeRoom: function removeRoom(elem) {
      alert("Clicked");
      alert(jquery__WEBPACK_IMPORTED_MODULE_1___default()(elem).parent('div').attr('id'));
    },
    loadNum: function loadNum() {
      this.min = 0;
      this.max = 3;
      this.getRandomNumber();
    },
    getInput: function getInput() {
      var min = Number(this.min);
      var max = Number(this.max);

      if (min > max) {
        var _ref = [max, min];
        min = _ref[0];
        max = _ref[1];
      }

      this.min = min;
      this.max = max;
      this.getRandomNumber();
    },
    onFileChange: function onFileChange(e) {
      var file = e.target.files[0];
      this.selectedFeatured = file;
      this.url = URL.createObjectURL(file);
    },
    uploadImage: function uploadImage(e) {
      var _this9 = this;

      var vm = this;
      var selectedFiles = e.target.files;

      for (var i = 0; i < selectedFiles.length; i++) {
        console.log(selectedFiles[i]);
        this.images.push(selectedFiles[i]);
      }

      var _loop = function _loop(_i) {
        var reader = new FileReader();

        reader.onload = function (e) {
          _this9.$refs.image[_i].src = reader.result;
          console.log(_this9.$refs.image[_i].src);
        };

        reader.readAsDataURL(_this9.images[_i]);
      };

      for (var _i = 0; _i < this.images.length; _i++) {
        _loop(_i);
      }
    },
    getRandomNumber: function getRandomNumber() {
      this.number = this.generateNumber();
    },
    generateNumber: function generateNumber() {
      return Math.floor(Math.random() * (this.max - this.min + 1) + this.min);
    },
    alert: function alert(title, text, color) {
      this.$vs.notify({
        color: color,
        title: title,
        text: text,
        position: 'top-right'
      });
    },
    handleClick: function handleClick(e) {
      if (e.target.matches('.cloneButton, .cloneButton *')) {}
    }
  },
  components: {
    FormWizard: vue_form_wizard__WEBPACK_IMPORTED_MODULE_2__["FormWizard"],
    TabContent: vue_form_wizard__WEBPACK_IMPORTED_MODULE_2__["TabContent"],
    'v-select': vue_select__WEBPACK_IMPORTED_MODULE_3___default.a
  },
  beforeMount: function beforeMount() {
    this.getManagers();
    this.getBasic();
    this.getAmen();
    this.getPolicy();
    this.getCat();
  }
});

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/update.vue?vue&type=template&id=9dd92aae&scoped=true&":
/*!*****************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/property/update.vue?vue&type=template&id=9dd92aae&scoped=true& ***!
  \*****************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c("div", { staticClass: "vx-row" }, [
    _c(
      "div",
      { staticClass: "vx-col w-full" },
      [
        _c("vx-card", { staticClass: "mb-4", attrs: { title: "Basic Info" } }, [
          _c("div", { staticClass: "vx-row" }, [
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required|alpha_spaces",
                      expression: "'required|alpha_spaces'"
                    }
                  ],
                  staticClass: "w-full mt-4",
                  attrs: {
                    label: "College Name",
                    type: "text",
                    name: "property_name"
                  },
                  model: {
                    value: _vm.property_name,
                    callback: function($$v) {
                      _vm.property_name = $$v
                    },
                    expression: "property_name"
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "text-danger" }, [
                  _vm._v(_vm._s(_vm.errors.first("step-2.property_name")))
                ]),
                _c("br"),
                _vm._v(" "),
                _c("label", { staticClass: "mt-2" }, [_vm._v("College Type")]),
                _vm._v(" "),
                _c("v-select", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  attrs: {
                    options: _vm.categories,
                    dir: _vm.$vs.rtl ? "rtl" : "ltr",
                    name: "property_type"
                  },
                  model: {
                    value: _vm.selectedCategory,
                    callback: function($$v) {
                      _vm.selectedCategory = $$v
                    },
                    expression: "selectedCategory"
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "text-danger" }, [
                  _vm._v(_vm._s(_vm.errors.first("step-2.property_type")))
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full" },
              [
                _c("vs-textarea", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  staticClass: "md:mt-10 mt-6 mb-0",
                  attrs: {
                    label: "Short Description",
                    name: "property_description",
                    rows: "3"
                  },
                  model: {
                    value: _vm.textarea,
                    callback: function($$v) {
                      _vm.textarea = $$v
                    },
                    expression: "textarea"
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "text-danger" }, [
                  _vm._v(
                    _vm._s(_vm.errors.first("step-2.property_description"))
                  )
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required|alpha_spaces",
                      expression: "'required|alpha_spaces'"
                    }
                  ],
                  staticClass: "w-full mt-4",
                  attrs: { label: "Language Spoken", name: "language_spoken" },
                  model: {
                    value: _vm.Language,
                    callback: function($$v) {
                      _vm.Language = $$v
                    },
                    expression: "Language"
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "text-danger" }, [
                  _vm._v(_vm._s(_vm.errors.first("step-2.language_spoken")))
                ]),
                _vm._v(" "),
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required|",
                      expression: "'required|'"
                    }
                  ],
                  staticClass: "w-full mt-4",
                  attrs: {
                    label: "Hotel Contact Number",
                    name: "hotel_contact"
                  },
                  model: {
                    value: _vm.Hotel,
                    callback: function($$v) {
                      _vm.Hotel = $$v
                    },
                    expression: "Hotel"
                  }
                }),
                _vm._v(" "),
                _c("span", { staticClass: "text-danger" }, [
                  _vm._v(_vm._s(_vm.errors.first("step-2.hotel_contact")))
                ]),
                _vm._v(" "),
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required|",
                      expression: "'required|'"
                    }
                  ],
                  staticClass: "w-full mt-4",
                  attrs: { label: "Email", name: "email" },
                  model: {
                    value: _vm.EmailEnter,
                    callback: function($$v) {
                      _vm.EmailEnter = $$v
                    },
                    expression: "EmailEnter"
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required|",
                      expression: "'required|'"
                    }
                  ],
                  staticClass: "w-full mt-4",
                  attrs: { label: "Property Size", name: "property_size" },
                  model: {
                    value: _vm.propSize,
                    callback: function($$v) {
                      _vm.propSize = $$v
                    },
                    expression: "propSize"
                  }
                }),
                _vm._v(" "),
                _c("div", { staticClass: "demo-alignment pt-5" }, [
                  _c("span", [_vm._v("Parking:")]),
                  _vm._v(" "),
                  _c(
                    "div",
                    { staticClass: "flex" },
                    [
                      _c(
                        "vs-radio",
                        {
                          staticClass: "mr-3",
                          attrs: { color: "success", "vs-value": "1" },
                          model: {
                            value: _vm.parkingSelect,
                            callback: function($$v) {
                              _vm.parkingSelect = $$v
                            },
                            expression: "parkingSelect"
                          }
                        },
                        [_vm._v("Yes")]
                      ),
                      _vm._v(" "),
                      _c(
                        "vs-radio",
                        {
                          attrs: { color: "danger", "vs-value": "0" },
                          model: {
                            value: _vm.parkingSelect,
                            callback: function($$v) {
                              _vm.parkingSelect = $$v
                            },
                            expression: "parkingSelect"
                          }
                        },
                        [_vm._v("No")]
                      )
                    ],
                    1
                  )
                ])
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col w-full" },
              [
                _c(
                  "vs-button",
                  {
                    staticStyle: { float: "right" },
                    on: { click: _vm.updateBasic }
                  },
                  [_vm._v("UPDATE")]
                )
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("vx-card", { staticClass: "mb-4", attrs: { title: "Address" } }, [
          _c("div", { staticClass: "vx-row" }, [
            _c(
              "div",
              { staticClass: "vx-col w-full" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  staticClass: "w-full mt-5",
                  attrs: { label: "Address", name: "address_text" },
                  model: {
                    value: _vm.addressValue,
                    callback: function($$v) {
                      _vm.addressValue = $$v
                    },
                    expression: "addressValue"
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  staticClass: "w-full mt-5",
                  attrs: { label: "Village", name: "village_name" },
                  model: {
                    value: _vm.village,
                    callback: function($$v) {
                      _vm.village = $$v
                    },
                    expression: "village"
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  staticClass: "w-full mt-5",
                  attrs: { label: "District", name: "district_name" },
                  model: {
                    value: _vm.district,
                    callback: function($$v) {
                      _vm.district = $$v
                    },
                    expression: "district"
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full mt-5" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  staticClass: "w-full mt-5",
                  attrs: { label: "Road Name", name: "road_name" },
                  model: {
                    value: _vm.roadName,
                    callback: function($$v) {
                      _vm.roadName = $$v
                    },
                    expression: "roadName"
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full mt-5" },
              [
                _c("vs-input", {
                  directives: [
                    {
                      name: "validate",
                      rawName: "v-validate",
                      value: "required",
                      expression: "'required'"
                    }
                  ],
                  staticClass: "w-full mt-5",
                  attrs: { label: "Pin Code", name: "pincode" },
                  model: {
                    value: _vm.pinCode,
                    callback: function($$v) {
                      _vm.pinCode = $$v
                    },
                    expression: "pinCode"
                  }
                })
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full mt-5" },
              [
                _c(
                  "vs-select",
                  {
                    staticClass: "w-full select-large",
                    attrs: { label: "City" },
                    model: {
                      value: _vm.citySelect,
                      callback: function($$v) {
                        _vm.citySelect = $$v
                      },
                      expression: "citySelect"
                    }
                  },
                  _vm._l(_vm.cityOptions, function(item, index) {
                    return _c("vs-select-item", {
                      key: index,
                      staticClass: "w-full",
                      attrs: { value: item.id, text: item.name }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col md:w-1/2 w-full mt-5" },
              [
                _c(
                  "vs-select",
                  {
                    staticClass: "w-full select-large",
                    attrs: { label: "State" },
                    model: {
                      value: _vm.stateSelect,
                      callback: function($$v) {
                        _vm.stateSelect = $$v
                      },
                      expression: "stateSelect"
                    }
                  },
                  _vm._l(_vm.stateOptions, function(item, index) {
                    return _c("vs-select-item", {
                      key: index,
                      staticClass: "w-full",
                      attrs: { value: item.id, text: item.name }
                    })
                  }),
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col w-full mt-5" },
              [
                _c("vs-button", { staticStyle: { float: "right" } }, [
                  _vm._v("UPDATE")
                ])
              ],
              1
            )
          ])
        ]),
        _vm._v(" "),
        _c("vx-card", { staticClass: "mb-4", attrs: { title: "Amenities" } }, [
          _c(
            "div",
            { staticClass: "vx-row" },
            [
              _c(
                "vs-tabs",
                { attrs: { color: "rgb(32, 201, 192)" } },
                [
                  this.getRandomNumber
                    ? _c(
                        "vs-tabs",
                        {
                          attrs: {
                            position: "left",
                            color: _vm.classes[_vm.number]
                          }
                        },
                        [
                          _vm._l(_vm.amenities, function(item, index) {
                            return _c(
                              "vs-tab",
                              { key: index, attrs: { label: item.name } },
                              [
                                _vm.amenities[index].children.length !== 0
                                  ? _c("span", [
                                      _c(
                                        "ul",
                                        { staticClass: "demo-alignment" },
                                        _vm._l(
                                          _vm.amenities[index].children,
                                          function(items, indexs) {
                                            return _c(
                                              "li",
                                              { key: indexs },
                                              [
                                                _c(
                                                  "vs-checkbox",
                                                  {
                                                    attrs: {
                                                      color:
                                                        _vm.classes[_vm.number],
                                                      "vs-value": items.id
                                                    },
                                                    model: {
                                                      value: _vm.amenitiesValue,
                                                      callback: function($$v) {
                                                        _vm.amenitiesValue = $$v
                                                      },
                                                      expression:
                                                        "amenitiesValue"
                                                    }
                                                  },
                                                  [_vm._v(_vm._s(items.name))]
                                                )
                                              ],
                                              1
                                            )
                                          }
                                        ),
                                        0
                                      )
                                    ])
                                  : _c("span", [
                                      _vm._v(
                                        "\n                                No Data\n                            "
                                      )
                                    ])
                              ]
                            )
                          }),
                          _vm._v(" "),
                          _c("vs-tab", {
                            attrs: { disabled: true, label: "Select Amenities" }
                          })
                        ],
                        2
                      )
                    : _vm._e()
                ],
                1
              )
            ],
            1
          )
        ]),
        _vm._v(" "),
        _c("vx-card", { staticClass: "mb-4", attrs: { title: "Rooms" } }, [
          _c("div", { staticClass: "vx-row" }, [
            _c(
              "div",
              { staticClass: "vx-row cloneDiv", attrs: { id: "room_card0" } },
              [
                _c("div", {
                  staticClass: "vx-col w-full mt-1",
                  attrs: { id: "ButtonPArent" }
                }),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required|alpha_spaces",
                          expression: "'required|alpha_spaces'"
                        }
                      ],
                      staticClass: "w-full mt-5",
                      attrs: { label: "Room Name", name: "room_name" },
                      model: {
                        value: _vm.roomName,
                        callback: function($$v) {
                          _vm.roomName = $$v
                        },
                        expression: "roomName"
                      }
                    }),
                    _vm._v(" "),
                    _c("span", { staticClass: "text-danger" })
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full" },
                  [
                    _c(
                      "vs-select",
                      {
                        staticClass: "w-full select-large mt-5",
                        attrs: { label: "No. Of Beds" },
                        model: {
                          value: _vm.noofbeds,
                          callback: function($$v) {
                            _vm.noofbeds = $$v
                          },
                          expression: "noofbeds"
                        }
                      },
                      _vm._l(_vm.bedOptions, function(item, index) {
                        return _c("vs-select-item", {
                          key: index,
                          staticClass: "w-full",
                          attrs: { value: item.value, text: item.text }
                        })
                      }),
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                  [
                    _c(
                      "vs-select",
                      {
                        staticClass: "w-full select-large",
                        attrs: { label: "Maximum Guest Allowed" },
                        model: {
                          value: _vm.maximum_guest,
                          callback: function($$v) {
                            _vm.maximum_guest = $$v
                          },
                          expression: "maximum_guest"
                        }
                      },
                      _vm._l(_vm.maximumGuestOptions, function(item, index) {
                        return _c("vs-select-item", {
                          key: index,
                          staticClass: "w-full",
                          attrs: { value: item.value, text: item.text }
                        })
                      }),
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                  [
                    _c(
                      "vs-select",
                      {
                        staticClass: "w-full select-large",
                        attrs: { label: "Room Type" },
                        model: {
                          value: _vm.room_type,
                          callback: function($$v) {
                            _vm.room_type = $$v
                          },
                          expression: "room_type"
                        }
                      },
                      _vm._l(_vm.roomTypeOptions, function(item, index) {
                        return _c("vs-select-item", {
                          key: index,
                          staticClass: "w-full",
                          attrs: { value: item.id, text: item.name }
                        })
                      }),
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full mt-5" },
                  [
                    _c(
                      "vs-select",
                      {
                        staticClass: "w-full select-large",
                        attrs: { label: "Attached Bathroom" },
                        model: {
                          value: _vm.attach_bathroom,
                          callback: function($$v) {
                            _vm.attach_bathroom = $$v
                          },
                          expression: "attach_bathroom"
                        }
                      },
                      _vm._l(_vm.bathroomOptions, function(item, index) {
                        return _c("vs-select-item", {
                          key: index,
                          staticClass: "w-full",
                          attrs: { value: item.value, text: item.text }
                        })
                      }),
                      1
                    )
                  ],
                  1
                ),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full mt-2" },
                  [
                    _c(
                      "vx-input-group",
                      { staticClass: "mb-base" },
                      [
                        _c(
                          "template",
                          { slot: "prepend" },
                          [
                            _c("vs-input", {
                              attrs: { label: "Length" },
                              model: {
                                value: _vm.RoomLength,
                                callback: function($$v) {
                                  _vm.RoomLength = $$v
                                },
                                expression: "RoomLength"
                              }
                            })
                          ],
                          1
                        ),
                        _vm._v(" "),
                        _c("vs-input", {
                          attrs: { label: "Breadth" },
                          model: {
                            value: _vm.RoomBreadth,
                            callback: function($$v) {
                              _vm.RoomBreadth = $$v
                            },
                            expression: "RoomBreadth"
                          }
                        })
                      ],
                      2
                    ),
                    _vm._v(" "),
                    _c("span", { staticClass: "text-danger" })
                  ],
                  1
                ),
                _vm._v(" "),
                _c("div", { staticClass: "vx-col md:w-1/2 w-full" }, [
                  _c("div", { staticClass: "demo-alignment pt-5" }, [
                    _c("span", [_vm._v("Extra Bed:")]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "flex" },
                      [
                        _c(
                          "vs-radio",
                          {
                            staticClass: "mx-2",
                            attrs: { color: "success", "vs-value": "1" },
                            model: {
                              value: _vm.beds,
                              callback: function($$v) {
                                _vm.beds = $$v
                              },
                              expression: "beds"
                            }
                          },
                          [_vm._v("Yes")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-radio",
                          {
                            attrs: { color: "danger", "vs-value": "1" },
                            model: {
                              value: _vm.beds,
                              callback: function($$v) {
                                _vm.beds = $$v
                              },
                              expression: "beds"
                            }
                          },
                          [_vm._v("No")]
                        )
                      ],
                      1
                    )
                  ]),
                  _vm._v(" "),
                  _c("div", { staticClass: "demo-alignment pt-5" }, [
                    _c("span", [_vm._v("Meal Option:")]),
                    _vm._v(" "),
                    _c(
                      "div",
                      { staticClass: "flex" },
                      [
                        _c(
                          "vs-checkbox",
                          {
                            attrs: { "vs-value": "Breakfast" },
                            on: { change: _vm.removeMealE },
                            model: {
                              value: _vm.MealOption,
                              callback: function($$v) {
                                _vm.MealOption = $$v
                              },
                              expression: "MealOption"
                            }
                          },
                          [_vm._v("Breakfast")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-checkbox",
                          {
                            attrs: { "vs-value": "Lunch" },
                            on: { change: _vm.removeMealE },
                            model: {
                              value: _vm.MealOption,
                              callback: function($$v) {
                                _vm.MealOption = $$v
                              },
                              expression: "MealOption"
                            }
                          },
                          [_vm._v("Lunch")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-checkbox",
                          {
                            attrs: { "vs-value": "Dinner" },
                            on: { change: _vm.removeMealE },
                            model: {
                              value: _vm.MealOption,
                              callback: function($$v) {
                                _vm.MealOption = $$v
                              },
                              expression: "MealOption"
                            }
                          },
                          [_vm._v("Dinner")]
                        ),
                        _vm._v(" "),
                        _c(
                          "vs-checkbox",
                          {
                            attrs: { "vs-value": "Exclude" },
                            on: { change: _vm.removeMeal },
                            model: {
                              value: _vm.MealOptionExclude,
                              callback: function($$v) {
                                _vm.MealOptionExclude = $$v
                              },
                              expression: "MealOptionExclude"
                            }
                          },
                          [_vm._v("Meal are Excluded")]
                        )
                      ],
                      1
                    )
                  ])
                ]),
                _vm._v(" "),
                _c(
                  "div",
                  { staticClass: "vx-col md:w-1/2 w-full" },
                  [
                    _c("vs-input", {
                      directives: [
                        {
                          name: "validate",
                          rawName: "v-validate",
                          value: "required",
                          expression: "'required'"
                        }
                      ],
                      staticClass: "w-full mt-5",
                      attrs: { label: "B2B Price", name: "b2b" },
                      model: {
                        value: _vm.b2bprice,
                        callback: function($$v) {
                          _vm.b2bprice = $$v
                        },
                        expression: "b2bprice"
                      }
                    }),
                    _vm._v(" "),
                    _c("span", { staticClass: "text-danger" })
                  ],
                  1
                )
              ]
            ),
            _vm._v(" "),
            _c("div", {
              staticClass: "vx-row mx-1",
              attrs: { id: "copy_room" },
              on: { click: _vm.handleClick }
            }),
            _vm._v(" "),
            _c("div", { staticClass: "vx-col w-full mt-1" })
          ])
        ]),
        _vm._v(" "),
        _c("vx-card", { staticClass: "mb-4", attrs: { title: "Photos" } }, [
          _c("div", { staticClass: "vx-row" }, [
            _c(
              "div",
              { staticClass: "vx-col w-full" },
              [
                _c(
                  "vx-card",
                  { staticClass: "mt-3", attrs: { title: "Featured Image" } },
                  [
                    _c("vs-row", [
                      _c("div", { staticClass: "vs-col" }, [
                        _c(
                          "div",
                          {
                            staticClass: "con-input-upload",
                            staticStyle: {
                              float: "unset",
                              width: "100% !important"
                            }
                          },
                          [
                            _c("input", {
                              attrs: { type: "file", id: "featuredImage" },
                              on: { change: _vm.onFileChange }
                            }),
                            _c("span", { staticClass: "text-input" }, [
                              _vm._v(" Upload File ")
                            ]),
                            _c("span", {
                              staticClass: "input-progress",
                              staticStyle: { width: "0%" }
                            }),
                            _c(
                              "button",
                              {
                                staticClass:
                                  "btn-upload-all vs-upload--button-upload",
                                attrs: {
                                  disabled: "disabled",
                                  type: "button",
                                  title: "Upload"
                                }
                              },
                              [
                                _c(
                                  "i",
                                  {
                                    staticClass: "material-icons notranslate",
                                    attrs: { translate: "translate" }
                                  },
                                  [_vm._v(" cloud_upload ")]
                                )
                              ]
                            )
                          ]
                        )
                      ]),
                      _vm._v(" "),
                      _c(
                        "div",
                        {
                          staticClass: "vs-col",
                          staticStyle: { margin: "0px 100px" },
                          attrs: { id: "preview" }
                        },
                        [
                          _vm.url
                            ? _c("img", {
                                staticStyle: { width: "300px", float: "right" },
                                attrs: { src: _vm.url }
                              })
                            : _vm._e()
                        ]
                      )
                    ])
                  ],
                  1
                )
              ],
              1
            ),
            _vm._v(" "),
            _c(
              "div",
              { staticClass: "vx-col w-full" },
              [
                _c(
                  "vx-card",
                  { staticClass: "mt-3", attrs: { title: "Gallery Images" } },
                  [
                    _c(
                      "vs-button",
                      {
                        staticStyle: { float: "right" },
                        on: { click: _vm.resetGallery }
                      },
                      [_vm._v("Reset")]
                    ),
                    _vm._v(" "),
                    _c(
                      "vs-row",
                      [
                        _c("div", { staticClass: "vs-col" }, [
                          _c(
                            "div",
                            {
                              staticClass: "con-input-upload",
                              staticStyle: {
                                float: "unset",
                                width: "100% !important"
                              }
                            },
                            [
                              _c("input", {
                                attrs: {
                                  type: "file",
                                  id: "galleryImage",
                                  multiple: ""
                                },
                                on: { change: _vm.uploadImage }
                              }),
                              _c("span", { staticClass: "text-input" }, [
                                _vm._v(" Upload File ")
                              ]),
                              _c("span", {
                                staticClass: "input-progress",
                                staticStyle: { width: "0%" }
                              }),
                              _c(
                                "button",
                                {
                                  staticClass:
                                    "btn-upload-all vs-upload--button-upload",
                                  attrs: {
                                    disabled: "disabled",
                                    type: "button",
                                    title: "Upload"
                                  }
                                },
                                [
                                  _c(
                                    "i",
                                    {
                                      staticClass: "material-icons notranslate",
                                      attrs: { translate: "translate" }
                                    },
                                    [_vm._v(" cloud_upload ")]
                                  )
                                ]
                              )
                            ]
                          )
                        ]),
                        _vm._v(" "),
                        _vm._l(_vm.images, function(image, key) {
                          return _c(
                            "div",
                            { key: key, staticClass: "vs-col" },
                            [
                              _c("div", [
                                _c("img", {
                                  ref: "image",
                                  refInFor: true,
                                  staticClass: "preview",
                                  staticStyle: { width: "20%" }
                                }),
                                _vm._v(
                                  "\n                                    " +
                                    _vm._s(image.name) +
                                    "\n                                "
                                )
                              ])
                            ]
                          )
                        })
                      ],
                      2
                    )
                  ],
                  1
                )
              ],
              1
            )
          ])
        ])
      ],
      1
    )
  ])
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/property/update.vue":
/*!****************************************************!*\
  !*** ./resources/js/src/views/property/update.vue ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _update_vue_vue_type_template_id_9dd92aae_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./update.vue?vue&type=template&id=9dd92aae&scoped=true& */ "./resources/js/src/views/property/update.vue?vue&type=template&id=9dd92aae&scoped=true&");
/* harmony import */ var _update_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./update.vue?vue&type=script&lang=js& */ "./resources/js/src/views/property/update.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _update_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _update_vue_vue_type_template_id_9dd92aae_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"],
  _update_vue_vue_type_template_id_9dd92aae_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  "9dd92aae",
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/property/update.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/property/update.vue?vue&type=script&lang=js&":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/property/update.vue?vue&type=script&lang=js& ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_update_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../node_modules/vue-loader/lib??vue-loader-options!./update.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/update.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_update_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/property/update.vue?vue&type=template&id=9dd92aae&scoped=true&":
/*!***********************************************************************************************!*\
  !*** ./resources/js/src/views/property/update.vue?vue&type=template&id=9dd92aae&scoped=true& ***!
  \***********************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_update_vue_vue_type_template_id_9dd92aae_scoped_true___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../node_modules/vue-loader/lib??vue-loader-options!./update.vue?vue&type=template&id=9dd92aae&scoped=true& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/property/update.vue?vue&type=template&id=9dd92aae&scoped=true&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_update_vue_vue_type_template_id_9dd92aae_scoped_true___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_update_vue_vue_type_template_id_9dd92aae_scoped_true___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);