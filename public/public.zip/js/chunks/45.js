(window["webpackJsonp"] = window["webpackJsonp"] || []).push([[45],{

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=script&lang=js&":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=script&lang=js& ***!
  \*********************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownDefault_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownDefault.vue */ "./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue");
/* harmony import */ var _DropdownColor_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DropdownColor.vue */ "./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue");
/* harmony import */ var _DropdownGroupOption_vue__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./DropdownGroupOption.vue */ "./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue");
/* harmony import */ var _DropdownCustomContent_vue__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./DropdownCustomContent.vue */ "./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue");
/* harmony import */ var _DropdownButton_vue__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./DropdownButton.vue */ "./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//





/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    DropdownDefault: _DropdownDefault_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    DropdownColor: _DropdownColor_vue__WEBPACK_IMPORTED_MODULE_1__["default"],
    DropdownGroupOption: _DropdownGroupOption_vue__WEBPACK_IMPORTED_MODULE_2__["default"],
    DropdownCustomContent: _DropdownCustomContent_vue__WEBPACK_IMPORTED_MODULE_3__["default"],
    DropdownButton: _DropdownButton_vue__WEBPACK_IMPORTED_MODULE_4__["default"]
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=script&lang=js&":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=script&lang=js& ***!
  \***************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_prism_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-prism-component */ "./node_modules/vue-prism-component/dist/vue-prism-component.common.js");
/* harmony import */ var vue_prism_component__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_prism_component__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      value1: '',
      value2: ''
    };
  },
  components: {
    Prism: vue_prism_component__WEBPACK_IMPORTED_MODULE_0___default.a
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      colorx: '#c80948'
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=script&lang=js&":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=script&lang=js& ***!
  \**********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
/* harmony default export */ __webpack_exports__["default"] = ({
  data: function data() {
    return {
      value1: '',
      value2: ''
    };
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=script&lang=js&":
/*!****************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=script&lang=js& ***!
  \****************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var vue_prism_component__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! vue-prism-component */ "./node_modules/vue-prism-component/dist/vue-prism-component.common.js");
/* harmony import */ var vue_prism_component__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(vue_prism_component__WEBPACK_IMPORTED_MODULE_0__);
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//

/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    Prism: vue_prism_component__WEBPACK_IMPORTED_MODULE_0___default.a
  }
});

/***/ }),

/***/ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/babel-loader/lib??ref--4-0!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _dropdownGroupOption_DropdownOptionGroup_vue__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dropdownGroupOption/DropdownOptionGroup.vue */ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue");
/* harmony import */ var _dropdownGroupOption_DropdownGroupCollapse_vue__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./dropdownGroupOption/DropdownGroupCollapse.vue */ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue");
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//


/* harmony default export */ __webpack_exports__["default"] = ({
  components: {
    DropdownOptionGroup: _dropdownGroupOption_DropdownOptionGroup_vue__WEBPACK_IMPORTED_MODULE_0__["default"],
    DropdownGroupCollapse: _dropdownGroupOption_DropdownGroupCollapse_vue__WEBPACK_IMPORTED_MODULE_1__["default"]
  }
});

/***/ }),

/***/ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss&":
/*!********************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss& ***!
  \********************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

exports = module.exports = __webpack_require__(/*! ../../../../../../../node_modules/css-loader/lib/css-base.js */ "./node_modules/css-loader/lib/css-base.js")(false);
// imports


// module
exports.push([module.i, "/*=========================================================================================\n    File Name: dropdown.scss\n    Description: Dropdown page styles\n    ----------------------------------------------------------------------------------------\n    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template\n      Author: Pixinvent\n    Author URL: http://www.themeforest.net/user/pixinvent\n==========================================================================================*/\n.dropdown-login {\n  z-index: 55000;\n}\n.dropdown-login .vs-dropdown--custom {\n  display: flex;\n  align-items: center;\n  flex-flow: column;\n}\n[dir] .dropdown-login .vs-dropdown--custom {\n  padding: 20px !important;\n}\n.dropdown-button-container {\n  display: flex;\n  align-items: center;\n}\n[dir=ltr] .dropdown-button-container .btnx {\n  border-radius: 5px 0px 0px 5px;\n}\n[dir=rtl] .dropdown-button-container .btnx {\n  border-radius: 0px 5px 5px 0px;\n}\n[dir=ltr] .dropdown-button-container .btn-drop {\n  border-radius: 0px 5px 5px 0px;\n  border-left: 1px solid rgba(255, 255, 255, 0.2);\n}\n[dir=rtl] .dropdown-button-container .btn-drop {\n  border-radius: 5px 0px 0px 5px;\n  border-right: 1px solid rgba(255, 255, 255, 0.2);\n}", ""]);

// exports


/***/ }),

/***/ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss&":
/*!************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/style-loader!./node_modules/css-loader!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src??ref--8-2!./node_modules/sass-loader/dist/cjs.js??ref--8-3!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss& ***!
  \************************************************************************************************************************************************************************************************************************************************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {


var content = __webpack_require__(/*! !../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Dropdown.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss&");

if(typeof content === 'string') content = [[module.i, content, '']];

var transform;
var insertInto;



var options = {"hmr":true}

options.transform = transform
options.insertInto = undefined;

var update = __webpack_require__(/*! ../../../../../../../node_modules/style-loader/lib/addStyles.js */ "./node_modules/style-loader/lib/addStyles.js")(content, options);

if(content.locals) module.exports = content.locals;

if(false) {}

/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=template&id=858555fa&":
/*!*************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=template&id=858555fa& ***!
  \*************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "div",
    { attrs: { id: "dropdown-demo" } },
    [
      _c("dropdown-default"),
      _vm._v(" "),
      _c("dropdown-color"),
      _vm._v(" "),
      _c("dropdown-group-option"),
      _vm._v(" "),
      _c("dropdown-custom-content"),
      _vm._v(" "),
      _c("dropdown-button")
    ],
    1
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=template&id=227fb315&":
/*!*******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=template&id=227fb315& ***!
  \*******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Button", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "You can customize the component or element that initialize the dropdown in this case, it is a Button that is the most common"
        )
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "The component or element that initializes the dropdown is the one inside it with the possibility of total customization and flexibility in the required use"
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "my-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "Vuesax uses the Google Material Icons font library by default. For a list of all available icons, visit the official "
            ),
            _c(
              "a",
              {
                attrs: { href: "https://material.io/icons/", target: "_blank" }
              },
              [_vm._v("Material Icons page")]
            ),
            _vm._v(".")
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              "FontAwesome and other fonts library are supported. Simply use the icon-pack with fa or fas. You still need to include the Font Awesome icons in your project."
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c("prism", { staticClass: "rounded-lg" }, [
        _vm._v(
          "\n<vs-dropdown>\n  <!-- element that initializes the dropdown -->\n\n  <vs-dropdown-menu>\n    <!-- items and elements within the menu or custom dropdown -->\n  </vs-dropdown-menu>\n</vs-dropdown>\n        "
        )
      ]),
      _vm._v(" "),
      _c("div", { staticClass: "mt-5 demo-alignment" }, [
        _c(
          "div",
          { staticClass: "dropdown-button-container" },
          [
            _c(
              "vs-button",
              { staticClass: "btnx", attrs: { type: "filled" } },
              [_vm._v("Dropdown")]
            ),
            _vm._v(" "),
            _c(
              "vs-dropdown",
              [
                _c("vs-button", {
                  staticClass: "btn-drop",
                  attrs: { type: "filled", icon: "expand_more" }
                }),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  [
                    _c("vs-dropdown-item", [_vm._v(" option 1 ")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v(" option 2 ")]),
                    _vm._v(" "),
                    _c(
                      "vs-dropdown-group",
                      [
                        _c("vs-dropdown-item", [_vm._v(" option 1 ")]),
                        _vm._v(" "),
                        _c("vs-dropdown-item", [_vm._v(" option 2 ")])
                      ],
                      1
                    ),
                    _vm._v(" "),
                    _c("vs-dropdown-item", { attrs: { divider: "" } }, [
                      _vm._v(" option 3 ")
                    ])
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "dropdown-button-container" },
          [
            _c(
              "vs-button",
              {
                staticClass: "btnx",
                attrs: { color: "success", type: "gradient" }
              },
              [_vm._v("Dropdown")]
            ),
            _vm._v(" "),
            _c(
              "vs-dropdown",
              [
                _c("vs-button", {
                  staticClass: "btn-drop",
                  attrs: {
                    color: "success",
                    type: "gradient",
                    icon: "more_horiz"
                  }
                }),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  [
                    _c("vs-dropdown-item", [_vm._v(" Home ")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [_vm._v(" Contributors ")]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", { attrs: { divider: "" } }, [
                      _vm._v(" Logout ")
                    ])
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        ),
        _vm._v(" "),
        _c(
          "div",
          { staticClass: "dropdown-button-container" },
          [
            _c(
              "vs-button",
              { staticClass: "btnx", attrs: { type: "line", color: "danger" } },
              [_vm._v("Icons")]
            ),
            _vm._v(" "),
            _c(
              "vs-dropdown",
              [
                _c("vs-button", {
                  staticClass: "btn-drop",
                  attrs: { type: "line", color: "danger", icon: "mood" }
                }),
                _vm._v(" "),
                _c(
                  "vs-dropdown-menu",
                  [
                    _c("vs-dropdown-item", [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v(" mood ")
                      ])
                    ]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v(" mood_bad ")
                      ])
                    ]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v(" sentiment_dissatisfied ")
                      ])
                    ]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v(" sentiment_satisfied ")
                      ])
                    ]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v(" sentiment_very_dissatisfied ")
                      ])
                    ]),
                    _vm._v(" "),
                    _c("vs-dropdown-item", [
                      _c("i", { staticClass: "material-icons" }, [
                        _vm._v(" sentiment_very_satisfied ")
                      ])
                    ])
                  ],
                  1
                )
              ],
              1
            )
          ],
          1
        )
      ]),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n  <div class="demo-alignment">\n\n    <!-- Dropdown Button 1 -->\n    <div class="dropdown-button-container">\n      <vs-button class="btnx" type="filled">Dropdown</vs-button>\n\n      <vs-dropdown>\n        <vs-button class="btn-drop" type="filled" icon="expand_more"></vs-button>\n        <vs-dropdown-menu>\n\n          <vs-dropdown-item> option 1 </vs-dropdown-item>\n          <vs-dropdown-item> option 2 </vs-dropdown-item>\n\n          <vs-dropdown-group>\n            <vs-dropdown-item> option 1 </vs-dropdown-item>\n            <vs-dropdown-item> option 2 </vs-dropdown-item>\n          </vs-dropdown-group>\n\n          <vs-dropdown-item divider> option 3 </vs-dropdown-item>\n        </vs-dropdown-menu>\n      </vs-dropdown>\n    </div>\n\n    <!-- Dropdown Button 2 -->\n    <div class="dropdown-button-container">\n      <vs-button class="btnx" color="success" type="gradient">Dropdown</vs-button>\n\n      <vs-dropdown>\n        <vs-button class="btn-drop" color="success" type="gradient" icon="more_horiz"></vs-button>\n        <vs-dropdown-menu>\n\n          <vs-dropdown-item> Home </vs-dropdown-item>\n          <vs-dropdown-item> Contributors </vs-dropdown-item>\n          <vs-dropdown-item divider> Logout </vs-dropdown-item>\n        </vs-dropdown-menu>\n      </vs-dropdown>\n    </div>\n\n    <!-- Dropdown Button 3 -->\n    <div class="dropdown-button-container">\n      <vs-button class="btnx" type="line" color="danger">Icons</vs-button>\n\n      <vs-dropdown>\n        <vs-button class="btn-drop" type="line" color="danger" icon="mood"></vs-button>\n        <vs-dropdown-menu>\n\n          <vs-dropdown-item>\n            <i class="material-icons"> mood </i>\n          </vs-dropdown-item>\n          <vs-dropdown-item>\n            <i class="material-icons"> mood_bad </i>\n          </vs-dropdown-item>\n          <vs-dropdown-item>\n            <i class="material-icons"> sentiment_dissatisfied </i>\n          </vs-dropdown-item>\n          <vs-dropdown-item>\n            <i class="material-icons"> sentiment_satisfied </i>\n          </vs-dropdown-item>\n          <vs-dropdown-item>\n            <i class="material-icons"> sentiment_very_dissatisfied </i>\n          </vs-dropdown-item>\n          <vs-dropdown-item>\n            <i class="material-icons"> sentiment_very_satisfied </i>\n          </vs-dropdown-item>\n        </vs-dropdown-menu>\n      </vs-dropdown>\n    </div>\n  </div>\n</template>\n\n<style lang="scss">\n.dropdown-button-container {\n  display: flex;\n  align-items: center;\n\n  .btnx {\n    border-radius: 5px 0px 0px 5px;\n  }\n\n  .btn-drop {\n    border-radius: 0px 5px 5px 0px;\n    border-left: 1px solid rgba(255, 255, 255, .2);\n  }\n}\n</style>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=template&id=c08e7e60&":
/*!******************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=template&id=c08e7e60& ***!
  \******************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Color", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v("You can change the color of the component with the property "),
        _c("code", [_vm._v("color")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { icon: "warning", active: "true", color: "warning" }
        },
        [
          _c("span", [
            _vm._v("Only "),
            _c("strong", [_vm._v("RGB")]),
            _vm._v(" and "),
            _c("strong", [_vm._v("HEX")]),
            _vm._v(" colors are supported.")
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5 demo-alignment" },
        [
          _c("input", {
            directives: [
              {
                name: "model",
                rawName: "v-model",
                value: _vm.colorx,
                expression: "colorx"
              }
            ],
            attrs: { type: "color" },
            domProps: { value: _vm.colorx },
            on: {
              input: function($event) {
                if ($event.target.composing) {
                  return
                }
                _vm.colorx = $event.target.value
              }
            }
          }),
          _vm._v(" "),
          _c(
            "vs-dropdown",
            { attrs: { color: _vm.colorx } },
            [
              _c(
                "a",
                { staticClass: "flex items-center", attrs: { href: "#" } },
                [
                  _vm._v(
                    "\n                    Dropdown hover\n                    "
                  ),
                  _c("i", { staticClass: "material-icons" }, [
                    _vm._v("expand_more")
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-dropdown-menu",
                [
                  _c("vs-dropdown-item", [
                    _vm._v(
                      "\n                        option 1\n                    "
                    )
                  ]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", [
                    _vm._v(
                      "\n                        option 2\n                    "
                    )
                  ]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", { attrs: { divider: "" } }, [
                    _vm._v(
                      "\n                        option 3\n                    "
                    )
                  ])
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n    <div class="demo-alignment">\n\n      <input type="color" v-model="colorx">\n\n      <vs-dropdown :color="colorx">\n        <a class="flex items-center" href="#">\n          Dropdown hover\n          <i class="material-icons">expand_more</i>\n        </a>\n\n        <vs-dropdown-menu>\n\n          <vs-dropdown-item>\n            option 1\n          </vs-dropdown-item>\n\n          <vs-dropdown-item>\n            option 2\n          </vs-dropdown-item>\n\n          <vs-dropdown-item divider>\n            option 3\n          </vs-dropdown-item>\n        </vs-dropdown-menu>\n      </vs-dropdown>\n    </div>\n</template>\n\n<script>\nexport default {\n  data: () => ({\n    colorx: \'#c80948\'\n  }),\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=template&id=0ca53c96&":
/*!**************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=template&id=0ca53c96& ***!
  \**************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Custom Content", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "Sometimes when we need something more personalized and not necessarily a menu for it you can add any content and have the dropdown functionality with the property "
        ),
        _c("code", [_vm._v("vs-custom-content")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "For better functionality in the user's aspect when doing some interaction with the custom dropdown you can add that it is only activated and deactivated by a click event with the property "
            ),
            _c("code", [_vm._v("vs-trigger-click")])
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5 demo-alignment" },
        [
          _c(
            "vs-dropdown",
            { attrs: { "vs-custom-content": "", "vs-trigger-click": "" } },
            [
              _c(
                "a",
                {
                  staticClass: "flex items-center",
                  attrs: { "href.prevent": "" }
                },
                [
                  _c("span", [_vm._v("Click me open login")]),
                  _vm._v(" "),
                  _c("feather-icon", {
                    attrs: {
                      icon: "ChevronDownIcon",
                      svgClasses: "h-4 w-4 ml-1"
                    }
                  })
                ],
                1
              ),
              _vm._v(" "),
              _c(
                "vs-dropdown-menu",
                { staticClass: "dropdown-login" },
                [
                  _c("h3", { staticClass: "mb-0" }, [_vm._v("Login")]),
                  _vm._v(" "),
                  _c("vs-input", {
                    attrs: { type: "email", "label-placeholder": "Email" },
                    model: {
                      value: _vm.value1,
                      callback: function($$v) {
                        _vm.value1 = $$v
                      },
                      expression: "value1"
                    }
                  }),
                  _vm._v(" "),
                  _c("vs-input", {
                    attrs: {
                      type: "password",
                      "label-placeholder": "Password"
                    },
                    model: {
                      value: _vm.value2,
                      callback: function($$v) {
                        _vm.value2 = $$v
                      },
                      expression: "value2"
                    }
                  }),
                  _vm._v(" "),
                  _c(
                    "vs-button",
                    {
                      staticClass: "mt-4 w-full",
                      attrs: {
                        width: "100%",
                        color: "success",
                        type: "gradient"
                      }
                    },
                    [_vm._v("Login")]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <vs-dropdown vs-custom-content vs-trigger-click>\n    <a class="flex items-center" href.prevent>\n      <span>Click me open login</span>\n      <feather-icon icon="ChevronDownIcon" svgClasses="h-4 w-4 ml-1" />\n    </a>\n\n    <vs-dropdown-menu class="dropdown-login">\n      <h3 class="mb-0">Login</h3>\n      <vs-input type="email" label-placeholder="Email" v-model="value1" />\n      <vs-input type="password" label-placeholder="Password" v-model="value2" />\n      <vs-button width="100%" color="success" type="gradient" class="mt-4 w-full">Login</vs-button>\n    </vs-dropdown-menu>\n\n  </vs-dropdown>\n</template>\n\n<script>\nexport default {\n  data: () => ({\n    value1: \'\',\n    value2: \'\',\n  }),\n}\n</script>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=template&id=7eea076e&":
/*!********************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=template&id=7eea076e& ***!
  \********************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Default", "code-toggler": "" } },
    [
      _c("p", [
        _vm._v(
          "To add the Dropdown we have three types of components the main "
        ),
        _c("code", [_vm._v("vs-dropdown")]),
        _vm._v(" that contains the element that makes the "),
        _c("code", [_vm._v("vs-dropdown-menu")]),
        _vm._v(" appear and to add each item within it we have the component "),
        _c("code", [_vm._v("vs-dropdown-item")])
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "mt-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v("To add an internal link using "),
            _c("a", { attrs: { href: "https://router.vuejs.org/" } }, [
              _vm._v("vue-router")
            ]),
            _vm._v(" you can do them simply by adding the property "),
            _c("a", { attrs: { href: "https://router.vuejs.org/api/#to" } }, [
              _vm._v("to")
            ]),
            _vm._v(" as if it were a "),
            _c("a", { attrs: { href: "https://router.vuejs.org/" } }, [
              _vm._v("vue-router")
            ]),
            _vm._v(" link")
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v(
              "In case you need an external link or normal html, simply do it with the href property"
            )
          ])
        ]
      ),
      _vm._v(" "),
      _c(
        "prism",
        { staticClass: "rounded-lg", attrs: { language: "markup" } },
        [
          _vm._v(
            '\n  <!-- to: internal link -->\n  <vs-dropdown-item to="/myLink">\n    my Link name\n  </vs-dropdown-item>\n\n  <!-- href: external link-->\n  <vs-dropdown-item href="/myLink">\n    my Link name\n  </vs-dropdown-item>\n            '
          )
        ]
      ),
      _vm._v(" "),
      _c(
        "div",
        { staticClass: "mt-5 demo-alignment" },
        [
          _c(
            "vs-dropdown",
            [
              _c(
                "a",
                { staticClass: "flex items-center", attrs: { href: "#" } },
                [
                  _vm._v(
                    "\n                    Dropdown hover\n                    "
                  ),
                  _c("i", { staticClass: "material-icons" }, [
                    _vm._v(" expand_more ")
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-dropdown-menu",
                [
                  _c("vs-dropdown-item", [
                    _vm._v(
                      "\n                        Option 1\n                    "
                    )
                  ]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", [
                    _vm._v(
                      "\n                        Option 2\n                    "
                    )
                  ]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", { attrs: { divider: "" } }, [
                    _vm._v(
                      "\n                        Option 3\n                    "
                    )
                  ])
                ],
                1
              )
            ],
            1
          ),
          _vm._v(" "),
          _c(
            "vs-dropdown",
            [
              _c(
                "a",
                {
                  staticClass: "flex items-center",
                  attrs: { "href.prevent": "" }
                },
                [
                  _vm._v(
                    "\n                    Dropdown Option Disabled\n                    "
                  ),
                  _c("i", { staticClass: "material-icons" }, [
                    _vm._v("expand_more")
                  ])
                ]
              ),
              _vm._v(" "),
              _c(
                "vs-dropdown-menu",
                [
                  _c("vs-dropdown-item", [
                    _vm._v(
                      "\n                        Option 1\n                    "
                    )
                  ]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", { attrs: { disabled: "" } }, [
                    _vm._v(
                      "\n                        Option 2\n                    "
                    )
                  ]),
                  _vm._v(" "),
                  _c(
                    "vs-dropdown-item",
                    { attrs: { disabled: "", divider: "" } },
                    [
                      _vm._v(
                        "\n                        Option 3\n                    "
                      )
                    ]
                  )
                ],
                1
              )
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<div class="demo-alignment">\n\n  <vs-dropdown>\n\n    <a class="flex items-center" href="#">\n      Dropdown hover\n      <i class="material-icons"> expand_more </i>\n    </a>\n\n    <vs-dropdown-menu>\n\n      <vs-dropdown-item>\n        Option 1\n      </vs-dropdown-item>\n\n      <vs-dropdown-item>\n        Option 2\n      </vs-dropdown-item>\n\n      <vs-dropdown-item divider>\n        Option 3\n      </vs-dropdown-item>\n\n    </vs-dropdown-menu>\n  </vs-dropdown>\n\n  <vs-dropdown>\n\n    <a class="flex items-center" href.prevent>\n      Dropdown Option Disabled\n      <i class="material-icons">expand_more</i>\n    </a>\n\n    <vs-dropdown-menu>\n\n      <vs-dropdown-item>\n        Option 1\n      </vs-dropdown-item>\n\n      <vs-dropdown-item disabled>\n        Option 2\n      </vs-dropdown-item>\n\n      <vs-dropdown-item disabled divider>\n        Option 3\n      </vs-dropdown-item>\n    </vs-dropdown-menu>\n  </vs-dropdown>\n</div>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=template&id=a56625fe&":
/*!************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=template&id=a56625fe& ***!
  \************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    { attrs: { title: "Group Option" } },
    [
      _c("p", [
        _vm._v(
          "If you need to group the options you can use the subcomponent "
        ),
        _c("code", [_vm._v("vs-dropdown-group")]),
        _vm._v(" which as a required parameter is "),
        _c("code", [_vm._v("vs-label")]),
        _vm._v(" to define the group title")
      ]),
      _vm._v(" "),
      _c(
        "vs-alert",
        {
          staticClass: "my-5",
          attrs: { color: "primary", icon: "new_releases", active: "true" }
        },
        [
          _c("p", [
            _vm._v(
              "The group can be hidden from the user and only open when it is sitting on the property with the "
            ),
            _c("code", [_vm._v("vs-collapse")]),
            _vm._v(" property")
          ]),
          _vm._v(" "),
          _c("p", [
            _vm._v("You can modify the icon with a property "),
            _c("code", [_vm._v("vs-icon")])
          ])
        ]
      ),
      _vm._v(" "),
      _c("dropdown-option-group"),
      _vm._v(" "),
      _c("dropdown-group-collapse"),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" })
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue?vue&type=template&id=3372c42d&":
/*!**********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue?vue&type=template&id=3372c42d& ***!
  \**********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      attrs: {
        title: "Group Collapse",
        "code-toggler": "",
        "no-shadow": "",
        "card-border": ""
      }
    },
    [
      _c(
        "vs-dropdown",
        [
          _c(
            "a",
            { staticClass: "flex items-center", attrs: { "href.prevent": "" } },
            [
              _vm._v(
                "\n                Dropdown Group Collapse\n                "
              ),
              _c("i", { staticClass: "material-icons" }, [
                _vm._v("expand_more")
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "vs-dropdown-menu",
            [
              _c("vs-dropdown-item", { attrs: { to: "/components/" } }, [
                _vm._v(" Option 1 ")
              ]),
              _vm._v(" "),
              _c("vs-dropdown-item", [_vm._v(" Option 2 ")]),
              _vm._v(" "),
              _c(
                "vs-dropdown-group",
                {
                  attrs: {
                    "vs-collapse": "",
                    "vs-label": "Group Collapse",
                    "vs-icon": "add"
                  }
                },
                [
                  _c("vs-dropdown-item", [_vm._v(" Option Collapse 1 ")]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", [_vm._v(" Option Collapse 2 ")]),
                  _vm._v(" "),
                  _c(
                    "vs-dropdown-group",
                    [
                      _c("vs-dropdown-item", [_vm._v(" Sub Options 1 ")]),
                      _vm._v(" "),
                      _c("vs-dropdown-item", [_vm._v(" Sub Options 2 ")]),
                      _vm._v(" "),
                      _c(
                        "vs-dropdown-group",
                        { attrs: { "vs-collapse": "" } },
                        [
                          _c(
                            "vs-dropdown-item",
                            { attrs: { "vs-label": "Sub Collapse" } },
                            [_vm._v(" Sub Collapse 1 ")]
                          ),
                          _vm._v(" "),
                          _c("vs-dropdown-item", [_vm._v(" Sub Collapse 2 ")])
                        ],
                        1
                      )
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("vs-dropdown-item", { attrs: { divider: "" } }, [
                _vm._v(" Option 3 ")
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div class="demo-alignment">\n\n    <vs-dropdown>\n\n      <a class="flex items-center" href.prevent>\n          Dropdown Group Collapse\n          <i class="material-icons">expand_more</i>\n      </a>\n\n      <vs-dropdown-menu>\n\n        <vs-dropdown-item to="/components/"> Option 1 </vs-dropdown-item>\n        <vs-dropdown-item> Option 2 </vs-dropdown-item>\n\n        <vs-dropdown-group vs-collapse vs-label="Group Collapse" vs-icon="add">\n\n          <vs-dropdown-item> Option Collapse 1 </vs-dropdown-item>\n          <vs-dropdown-item> Option Collapse 2 </vs-dropdown-item>\n\n          <vs-dropdown-group>\n\n            <vs-dropdown-item> Sub Options 1 </vs-dropdown-item>\n            <vs-dropdown-item> Sub Options 2 </vs-dropdown-item>\n\n            <vs-dropdown-group vs-collapse>\n\n              <vs-dropdown-item vs-label="Sub Collapse"> Sub Collapse 1 </vs-dropdown-item>\n              <vs-dropdown-item> Sub Collapse 2 </vs-dropdown-item>\n\n            </vs-dropdown-group>\n          </vs-dropdown-group>\n        </vs-dropdown-group>\n\n        <vs-dropdown-item divider> Option 3 </vs-dropdown-item>\n      </vs-dropdown-menu>\n    </vs-dropdown>\n  </div>\n</template>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa&":
/*!********************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!./node_modules/vue-loader/lib??vue-loader-options!./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa& ***!
  \********************************************************************************************************************************************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "render", function() { return render; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return staticRenderFns; });
var render = function() {
  var _vm = this
  var _h = _vm.$createElement
  var _c = _vm._self._c || _h
  return _c(
    "vx-card",
    {
      attrs: {
        title: "Option Grouping",
        "code-toggler": "",
        "no-shadow": "",
        "card-border": ""
      }
    },
    [
      _c(
        "vs-dropdown",
        [
          _c(
            "a",
            { staticClass: "flex items-center", attrs: { "href.prevent": "" } },
            [
              _vm._v(
                "\n                Dropdown Option Group\n                "
              ),
              _c("i", { staticClass: "material-icons" }, [
                _vm._v(" expand_more ")
              ])
            ]
          ),
          _vm._v(" "),
          _c(
            "vs-dropdown-menu",
            [
              _c("vs-dropdown-item", [_vm._v(" Option 1 ")]),
              _vm._v(" "),
              _c("vs-dropdown-item", [_vm._v(" Option 2 ")]),
              _vm._v(" "),
              _c(
                "vs-dropdown-group",
                [
                  _c("vs-dropdown-item", [_vm._v(" Option 1 ")]),
                  _vm._v(" "),
                  _c("vs-dropdown-item", [_vm._v(" Option 2 ")]),
                  _vm._v(" "),
                  _c(
                    "vs-dropdown-group",
                    [
                      _c("vs-dropdown-item", [_vm._v(" sub Options 1 ")]),
                      _vm._v(" "),
                      _c("vs-dropdown-item", [_vm._v(" sub Options 2 ")])
                    ],
                    1
                  )
                ],
                1
              ),
              _vm._v(" "),
              _c("vs-dropdown-item", { attrs: { divider: "" } }, [
                _vm._v(" Option 3 ")
              ])
            ],
            1
          )
        ],
        1
      ),
      _vm._v(" "),
      _c("template", { slot: "codeContainer" }, [
        _vm._v(
          '\n<template>\n\n  <div class="demo-alignment">\n\n    <vs-dropdown>\n\n      <a class="flex items-center" href.prevent>\n          Dropdown Option Group\n          <i class="material-icons"> expand_more </i>\n      </a>\n\n      <vs-dropdown-menu>\n\n        <vs-dropdown-item> Option 1 </vs-dropdown-item>\n        <vs-dropdown-item> Option 2 </vs-dropdown-item>\n\n        <vs-dropdown-group>\n\n          <vs-dropdown-item> Option 1 </vs-dropdown-item>\n          <vs-dropdown-item> Option 2 </vs-dropdown-item>\n\n          <vs-dropdown-group>\n\n            <vs-dropdown-item> sub Options 1 </vs-dropdown-item>\n            <vs-dropdown-item> sub Options 2 </vs-dropdown-item>\n\n          </vs-dropdown-group>\n        </vs-dropdown-group>\n\n        <vs-dropdown-item divider> Option 3 </vs-dropdown-item>\n      </vs-dropdown-menu>\n    </vs-dropdown>\n  </div>\n</template>\n\n<template>\n        '
        )
      ])
    ],
    2
  )
}
var staticRenderFns = []
render._withStripped = true



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue":
/*!************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue ***!
  \************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Dropdown_vue_vue_type_template_id_858555fa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Dropdown.vue?vue&type=template&id=858555fa& */ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=template&id=858555fa&");
/* harmony import */ var _Dropdown_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./Dropdown.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _Dropdown_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Dropdown.vue?vue&type=style&index=0&lang=scss& */ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");






/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_3__["default"])(
  _Dropdown_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _Dropdown_vue_vue_type_template_id_858555fa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _Dropdown_vue_vue_type_template_id_858555fa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/Dropdown.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=script&lang=js&":
/*!*************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=script&lang=js& ***!
  \*************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Dropdown.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss&":
/*!**********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss& ***!
  \**********************************************************************************************************/
/*! no static exports found */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/style-loader!../../../../../../../node_modules/css-loader!../../../../../../../node_modules/vue-loader/lib/loaders/stylePostLoader.js!../../../../../../../node_modules/postcss-loader/src??ref--8-2!../../../../../../../node_modules/sass-loader/dist/cjs.js??ref--8-3!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Dropdown.vue?vue&type=style&index=0&lang=scss& */ "./node_modules/style-loader/index.js!./node_modules/css-loader/index.js!./node_modules/vue-loader/lib/loaders/stylePostLoader.js!./node_modules/postcss-loader/src/index.js?!./node_modules/sass-loader/dist/cjs.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=style&index=0&lang=scss&");
/* harmony import */ var _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__);
/* harmony reexport (unknown) */ for(var __WEBPACK_IMPORT_KEY__ in _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__) if(["default"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) (function(key) { __webpack_require__.d(__webpack_exports__, key, function() { return _node_modules_style_loader_index_js_node_modules_css_loader_index_js_node_modules_vue_loader_lib_loaders_stylePostLoader_js_node_modules_postcss_loader_src_index_js_ref_8_2_node_modules_sass_loader_dist_cjs_js_ref_8_3_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_style_index_0_lang_scss___WEBPACK_IMPORTED_MODULE_0__[key]; }) }(__WEBPACK_IMPORT_KEY__));


/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=template&id=858555fa&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=template&id=858555fa& ***!
  \*******************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_template_id_858555fa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./Dropdown.vue?vue&type=template&id=858555fa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/Dropdown.vue?vue&type=template&id=858555fa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_template_id_858555fa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_Dropdown_vue_vue_type_template_id_858555fa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue":
/*!******************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue ***!
  \******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownButton_vue_vue_type_template_id_227fb315___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownButton.vue?vue&type=template&id=227fb315& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=template&id=227fb315&");
/* harmony import */ var _DropdownButton_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DropdownButton.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DropdownButton_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DropdownButton_vue_vue_type_template_id_227fb315___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownButton_vue_vue_type_template_id_227fb315___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=script&lang=js&":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=script&lang=js& ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownButton_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownButton.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownButton_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=template&id=227fb315&":
/*!*************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=template&id=227fb315& ***!
  \*************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownButton_vue_vue_type_template_id_227fb315___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownButton.vue?vue&type=template&id=227fb315& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownButton.vue?vue&type=template&id=227fb315&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownButton_vue_vue_type_template_id_227fb315___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownButton_vue_vue_type_template_id_227fb315___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue":
/*!*****************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownColor_vue_vue_type_template_id_c08e7e60___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownColor.vue?vue&type=template&id=c08e7e60& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=template&id=c08e7e60&");
/* harmony import */ var _DropdownColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DropdownColor.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DropdownColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DropdownColor_vue_vue_type_template_id_c08e7e60___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownColor_vue_vue_type_template_id_c08e7e60___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=script&lang=js&":
/*!******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=script&lang=js& ***!
  \******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownColor.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownColor_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=template&id=c08e7e60&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=template&id=c08e7e60& ***!
  \************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownColor_vue_vue_type_template_id_c08e7e60___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownColor.vue?vue&type=template&id=c08e7e60& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownColor.vue?vue&type=template&id=c08e7e60&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownColor_vue_vue_type_template_id_c08e7e60___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownColor_vue_vue_type_template_id_c08e7e60___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue":
/*!*************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownCustomContent_vue_vue_type_template_id_0ca53c96___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownCustomContent.vue?vue&type=template&id=0ca53c96& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=template&id=0ca53c96&");
/* harmony import */ var _DropdownCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DropdownCustomContent.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DropdownCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DropdownCustomContent_vue_vue_type_template_id_0ca53c96___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownCustomContent_vue_vue_type_template_id_0ca53c96___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=script&lang=js&":
/*!**************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=script&lang=js& ***!
  \**************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownCustomContent.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownCustomContent_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=template&id=0ca53c96&":
/*!********************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=template&id=0ca53c96& ***!
  \********************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownCustomContent_vue_vue_type_template_id_0ca53c96___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownCustomContent.vue?vue&type=template&id=0ca53c96& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownCustomContent.vue?vue&type=template&id=0ca53c96&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownCustomContent_vue_vue_type_template_id_0ca53c96___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownCustomContent_vue_vue_type_template_id_0ca53c96___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue":
/*!*******************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownDefault_vue_vue_type_template_id_7eea076e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownDefault.vue?vue&type=template&id=7eea076e& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=template&id=7eea076e&");
/* harmony import */ var _DropdownDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DropdownDefault.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DropdownDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DropdownDefault_vue_vue_type_template_id_7eea076e___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownDefault_vue_vue_type_template_id_7eea076e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=script&lang=js&":
/*!********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=script&lang=js& ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownDefault.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownDefault_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=template&id=7eea076e&":
/*!**************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=template&id=7eea076e& ***!
  \**************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownDefault_vue_vue_type_template_id_7eea076e___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownDefault.vue?vue&type=template&id=7eea076e& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownDefault.vue?vue&type=template&id=7eea076e&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownDefault_vue_vue_type_template_id_7eea076e___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownDefault_vue_vue_type_template_id_7eea076e___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue":
/*!***********************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownGroupOption_vue_vue_type_template_id_a56625fe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownGroupOption.vue?vue&type=template&id=a56625fe& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=template&id=a56625fe&");
/* harmony import */ var _DropdownGroupOption_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./DropdownGroupOption.vue?vue&type=script&lang=js& */ "./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport *//* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");





/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_2__["default"])(
  _DropdownGroupOption_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_1__["default"],
  _DropdownGroupOption_vue_vue_type_template_id_a56625fe___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownGroupOption_vue_vue_type_template_id_a56625fe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=script&lang=js&":
/*!************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=script&lang=js& ***!
  \************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupOption_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/babel-loader/lib??ref--4-0!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownGroupOption.vue?vue&type=script&lang=js& */ "./node_modules/babel-loader/lib/index.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=script&lang=js&");
/* empty/unused harmony star reexport */ /* harmony default export */ __webpack_exports__["default"] = (_node_modules_babel_loader_lib_index_js_ref_4_0_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupOption_vue_vue_type_script_lang_js___WEBPACK_IMPORTED_MODULE_0__["default"]); 

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=template&id=a56625fe&":
/*!******************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=template&id=a56625fe& ***!
  \******************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupOption_vue_vue_type_template_id_a56625fe___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownGroupOption.vue?vue&type=template&id=a56625fe& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/DropdownGroupOption.vue?vue&type=template&id=a56625fe&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupOption_vue_vue_type_template_id_a56625fe___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupOption_vue_vue_type_template_id_a56625fe___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue":
/*!*********************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownGroupCollapse_vue_vue_type_template_id_3372c42d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownGroupCollapse.vue?vue&type=template&id=3372c42d& */ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue?vue&type=template&id=3372c42d&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _DropdownGroupCollapse_vue_vue_type_template_id_3372c42d___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownGroupCollapse_vue_vue_type_template_id_3372c42d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue?vue&type=template&id=3372c42d&":
/*!****************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue?vue&type=template&id=3372c42d& ***!
  \****************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupCollapse_vue_vue_type_template_id_3372c42d___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownGroupCollapse.vue?vue&type=template&id=3372c42d& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownGroupCollapse.vue?vue&type=template&id=3372c42d&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupCollapse_vue_vue_type_template_id_3372c42d___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownGroupCollapse_vue_vue_type_template_id_3372c42d___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue":
/*!*******************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue ***!
  \*******************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _DropdownOptionGroup_vue_vue_type_template_id_edf7b9aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa& */ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa&");
/* harmony import */ var _node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../../../../../../node_modules/vue-loader/lib/runtime/componentNormalizer.js */ "./node_modules/vue-loader/lib/runtime/componentNormalizer.js");

var script = {}


/* normalize component */

var component = Object(_node_modules_vue_loader_lib_runtime_componentNormalizer_js__WEBPACK_IMPORTED_MODULE_1__["default"])(
  script,
  _DropdownOptionGroup_vue_vue_type_template_id_edf7b9aa___WEBPACK_IMPORTED_MODULE_0__["render"],
  _DropdownOptionGroup_vue_vue_type_template_id_edf7b9aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"],
  false,
  null,
  null,
  null
  
)

/* hot reload */
if (false) { var api; }
component.options.__file = "resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue"
/* harmony default export */ __webpack_exports__["default"] = (component.exports);

/***/ }),

/***/ "./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa&":
/*!**************************************************************************************************************************************!*\
  !*** ./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa& ***!
  \**************************************************************************************************************************************/
/*! exports provided: render, staticRenderFns */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownOptionGroup_vue_vue_type_template_id_edf7b9aa___WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! -!../../../../../../../../node_modules/vue-loader/lib/loaders/templateLoader.js??vue-loader-options!../../../../../../../../node_modules/vue-loader/lib??vue-loader-options!./DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa& */ "./node_modules/vue-loader/lib/loaders/templateLoader.js?!./node_modules/vue-loader/lib/index.js?!./resources/js/src/views/components/vuesax/dropdown/dropdownGroupOption/DropdownOptionGroup.vue?vue&type=template&id=edf7b9aa&");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "render", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownOptionGroup_vue_vue_type_template_id_edf7b9aa___WEBPACK_IMPORTED_MODULE_0__["render"]; });

/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "staticRenderFns", function() { return _node_modules_vue_loader_lib_loaders_templateLoader_js_vue_loader_options_node_modules_vue_loader_lib_index_js_vue_loader_options_DropdownOptionGroup_vue_vue_type_template_id_edf7b9aa___WEBPACK_IMPORTED_MODULE_0__["staticRenderFns"]; });



/***/ })

}]);