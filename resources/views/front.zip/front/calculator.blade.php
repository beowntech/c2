@extends('front.layout.header')
@section('content')
    <section class="bg-light" style="padding: 20px;">
            <div class="container bg-white border " style="border-radius: 8px;
    box-shadow: 0 4px 8px 0 rgb(0 0 0 / 20%), 0 6px 20px 0 rgb(0 0 0 / 19%);">
               
                        <div id="widget"> 
                        <div class="row">
                            <div class=" col-md-7 px-3 mb-4">
                                	<div class="row">
                                		<div class="col-md-5 mb-2">
                                			<canvas id="myChart" width="70%"></canvas>    
                                		</div>
                                		<div class="col-md-6">
                                			<div class="row text-center py-md-5">
                                				<div class="col-6 border ">Principal Amount</div>
                                				<div class="col-6 border "><p><i class="fa fa-rupee"></i> <span class="font-weight-bold TotalValue"></span></p></div>
                                				<div class="col-6 border">Interest Payable</div>
                                				<div class="col-6 border  font-weight-bold"><p><i class="fa fa-rupee"></i> <span class="interestValue"></span></p></div>	
                                				<div class="col-6 border">Monthly EMI</div>
                                				<div class="col-6 border  font-weight-bold"><p><i class="fa fa-rupee"></i> <span class="emiValue"></span></p></div>				
                                			</div>
                                		</div>
                                	</div>
                            </div>
                            <div class="col-md-5 px-3 mb-4">
                                <div class="form-group">
                                    <div class="range_indicator">
                                        <label for="loan-amount">File the Loan Amount <span>In Lakhs</span> </label>
                                        <div class="indi_rgt"><i class="fa fa-rupee"></i> <span id="selected-amount"></span> Lakhs </div>
                                    </div>
                                    <div id="loan-amount"></div>
                                    <span class="scalerange">
                        <span>0</span>
                        <span>10L</span>
                        <span>20L</span>
                        <span>30L</span>
                        <span>40L</span>
                        <span>50L</span>
                        <span>60L</span>
                        <span>70L</span>
                        <span>80L</span>
                        <span>90L</span>
                        <!--<span>1CR</span>-->
                      </span>
                                </div>

                                <div class="form-group">
                                    <div class="range_indicator">
                                        <label for="loan-duration">Rate of Interest</label>
                                        <div class="indi_rgt"><span id="selected-interest"></span> % </div>
                                    </div>
                                    <div id="interest-rate"></div>
                                    <span class="scalerange">
                        <span>5</span>
                        <span>7.5</span>
                        <span>10</span>
                        <span>12.5</span>
                        <span>15</span>
                        <span>17.5</span>
                        <span>20</span>
                        <span>22.5</span>
                      </span>
                                </div>


                                <div class="form-group">
                                    <div class="range_indicator">
                                        <label for="loan-duration">Loan Tenure</label>
                                        <div class="indi_rgt"><span id="selected-duration"></span> Years </div>
                                    </div>
                                    <div id="loan-duration"></div>
                                    <span class="scalerange">
                        <span>0</span>
                        <span>5</span>
                        <span>10</span>
                        <span>15</span>
                        <span>20</span>
                        <span>25</span>
                        <span>30</span>
                        <span>35</span>
                      </span>
                                </div>
                            </div>
                            
                        </div>
                </div><!-- row -->
            </div><!-- container -->
    </section>
@endsection
