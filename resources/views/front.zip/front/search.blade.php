@extends('front.layout.header')
@section('content')
<section class="bg-light">
    <div class="container">
        <div class="row">
           <div class="col-md-3 filter bg-white my-2 p-0">
                <div><h2 class="filter-heading"> filter</h2></div>
                <div class="filter-area">
                      @foreach($categories as $c => $ca)
                    <div class="form-check">
                        <input class="form-check-input categoryCheck" type="checkbox" {{ app('request')->input('catg') == $ca[0]->name ? "checked": "" }} value="{{$ca[0]->name}}" id="categoryCheck[]">
                        <label class="form-check-label" for="categoryCheck">
                            {{$ca[0]->name}}
                        </label>
                    </div>
                    @endforeach
                </div>
                <div><h2 class="filter-heading"> By Location</h2></div>
                <div class="filter-area">
                    <div class="form-group">
                        <label style="font-size: 14px;padding: 5px;" for="stateFilter">Select State</label>
                        <select id="stateFilter">
                        </select>
                    </div>
                    <div class="form-group" id="cityFilterDIV">
                        <label style="font-size: 14px;padding: 5px;" for="cityFilter">Select City</label>
                    <select id="cityFilter">
                    </select>
                    </div>
                </div>
                <div><h2 class="filter-heading"> By Review</h2></div>
                <div class="filter-area">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                           <span class="golden-color float-end">
                               <i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i>
                               </span>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
                        <label class="form-check-label" for="flexCheckChecked">
                            <span class="golden-color float-end">
                               <i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i>
                               </span>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckDefault">
                        <label class="form-check-label" for="flexCheckDefault">
                             <span class="golden-color float-end">
                               <i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i>
                               </span>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
                        <label class="form-check-label" for="flexCheckChecked">
                             <span class="golden-color float-end">
                               <i class="fa fa-star" aria-hidden="true"></i><i class="fa fa-star" aria-hidden="true"></i>
                               </span>
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="" id="flexCheckChecked">
                        <label class="form-check-label" for="flexCheckChecked">
                             <span class="golden-color float-end">
                               <i class="fa fa-star" aria-hidden="true"></i></span>
                        </label>
                    </div>
                </div>
            </div>
             <div class="col-md-9">
                <div class="bg-white mt-2" style="padding: 10px;border: white;border-radius: 10px;">
                    <div class="row">
                        <div class="col-md-8">
                        </div>
                        <div class="col-md-4">
                            Sort By
                            <button type="button" class="btn bg-transparent ml-1 sortPopularity">Popularity</button>
                            <button type="button" class="btn bg-transparent sortRating">Rating</button>
                        </div>
                    </div>
                </div>
                <div id="searchData">
                @foreach($data as $k => $val)
                    @if($val->featured == 1)
                <div class="row college-info-2">
                    <div class="col-md-4">
                        <div class="position-relative">
                            <div class="cover-img box" style="background:url(/property/{{$val->id}}/gallery/images/{{json_decode($val->images[0]->images)[0]}});background-size:cover;">
                                <div class="ribbon"><span>featured</span></div>
                                <div class="college-info-logo position-absolute bottom-0 start-5 p-2 ">
                                    <a href="#"> <img src="/property//{{$val->id}}/logo/{{$val->logo}}" alt=""></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8 college-info position-relative">
                        <p><a href="/college-in-{{str_replace(' ','_',str_replace('/[^A-Za-z0-9\-]/', '-',strtolower($val->cities[0]->name)))}}/{{$val->seo->permalink}}">{{$val->name}}</a></p>
                        <p><span><i class="fas fa-map-marker-alt"></i> {{$val->states[0]->name}}, <i class="fas fa-certificate"></i> UNI</span></p>
                        <p>
                            @foreach($val->courses as $c => $course)
                                @if($c < 2)
                            <span style="max-width: 100px;display: inline-block" class="text-truncate badge rounded-pill bg-light text-dark">{{$course->name}}</span>
                                @endif
                            @endforeach
                            <span class="badge rounded-pill bg-warning text-dark">+ more</span>
                        </p>

                        <div class="position-absolute top-0 end-0 pe-2">
                            <span class="badge bg-warning"><i class="far fa-star"></i> {{$val->reviews->isEmpty() ? "0" : $val->reviews->avg('stars')}} /5</span>
                        </div>
                        <div class="position-absolute bottom-0 end-0 pe-2 pb-2">
                            <a href="#" class="btn site-btn-1 btn-sm text-white quickEnquiryDetail" data-name="{{$val->name}}" data-location="{{$val->states[0]->name}}"  data-bs-toggle="modal" data-bs-target="#exampleModal">Quick Enquiry</a>
                            <a href="/college-in-{{str_replace(' ','_',str_replace('/[^A-Za-z0-9\-]/', '-',strtolower($val->cities[0]->name)))}}/{{$val->seo->permalink}}" class="btn site-btn-1 btn-sm text-white">Visit College</a>
                            <button type="button" data-id="{{$val->id}}" data-name="{{$val->name}}" data-image="{{$val->logo}}" class="btn site-btn-2 btn-sm openCompare" >Compare</button>
                        </div>
                    </div>
                </div>
                    @else
                        <div class="row college-info-2">
                            <div class="col-md-4">
                                <div class="position-relative">
                                    <div class="cover-img box" style="background:url(/property/{{$val->id}}/gallery/images/{{json_decode($val->images[0]->images)[0]}});background-size:cover;">
                                        <div class="college-info-logo position-absolute bottom-0 start-5 p-2 ">
                                            <a href=""> <img src="/property//{{$val->id}}/logo/{{$val->logo}}" alt=""></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-8 college-info position-relative">
                                <p><a href="/college-in-{{str_replace(' ','_',str_replace('/[^A-Za-z0-9\-]/', '-',strtolower($val->cities[0]->name)))}}/{{$val->seo->permalink}}">{{$val->name}}</a></p>
                                <p><span><i class="fas fa-map-marker-alt"></i> {{$val->states[0]->name}}, <i class="fas fa-certificate"></i> UNI</span></p>
                                <p>
                                    @foreach($val->courses as $c => $course)
                                        @if($c < 5)
                                            <span style="max-width: 100px;display: inline-block" class="text-truncate badge rounded-pill bg-light text-dark">{{$course->name}}</span>
                                        @endif
                                    @endforeach
                                    <span class="badge rounded-pill bg-warning text-dark">+ more</span>
                                </p>

                                <div class="position-absolute top-0 end-0 pe-2">
                                    <span class="badge bg-warning"><i class="far fa-star"></i> {{$val->reviews->isEmpty() ? "0" : $val->reviews->avg('stars')}}</span>
                                </div>
                                <div class="position-absolute bottom-0 end-0 pe-2 pb-2">
                                    <a href="#" class="btn site-btn-1 btn-sm text-white quickEnquiryDetail" data-name="{{$val->name}}" data-location="{{$state[0]->name}}" data-bs-toggle="modal" data-bs-target="#exampleModal">Quick Enquiry</a>
                                    <a href="/college-in-{{str_replace(' ','_',str_replace('/[^A-Za-z0-9\-]/', '-',strtolower($val->cities[0]->name)))}}/{{$val->seo->permalink}}" class="btn site-btn-1 btn-sm text-white">Visit College</a>
                                    <button type="button" class="btn site-btn-2 btn-sm openCompare" data-id="{{$val->id}}" data-name="{{$val->name}}" data-image="{{$val->logo}}" > Compare</button>
                                </div>
                            </div>
                        </div>
                    @endif
                @endforeach
                </div>
<!--                <nav aria-label="Page navigation example">-->
<!--                    <ul class="pagination justify-content-end">-->
<!--                        <li class="page-item disabled">-->
<!--                            <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>-->
<!--                        </li>-->
<!--                        <li class="page-item active"><a class="page-link" href="#">1</a></li>-->
<!--{{--                        <li class="page-item"><a class="page-link" href="#">2</a></li>--}}-->
<!--{{--                        <li class="page-item"><a class="page-link" href="#">3</a></li>--}}-->
<!--                        <li class="page-item disabled">-->
<!--                            <a class="page-link " href="#">Next</a>-->
<!--                        </li>-->
<!--                    </ul>-->
<!--                </nav>-->
            </div>
        </div>
    </div>
</section>
@endsection
