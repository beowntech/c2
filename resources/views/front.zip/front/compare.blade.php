@extends('front.layout.header')
@section('content')
<section id="compare-table">
    <div class="container">
        <div class="row my-4">
            <div class="col">
                <h1 class="site-title">Compare</h1>
                <p class="title-desc">Choose Top of the best Colleges / Exams </p>
            </div>
        </div>
        <div class="row">
            <div class="col table-responsive-sm">
                <table class="table table-striped table-bordered">
                    <thead>
                    <tr class="text-center">
                        <th scope="col align-middle"><img src="/assets/images/logo-2.png" width="90px" class="align-middle py-5" alt=""></th>
                        <th scope="col align-middle" >
                            <div id="compareOneShow">
                            <div class="college-info-1">
                                <div class="cover-img position-relative box" style="background:url(assets/images/slider/s1.jpg);background-size:cover;">
                                    <div class="ribbon"><span>featured</span></div>
                                    <a href="#"><div class="college-info-logo position-absolute bottom-0 start-0 px-2 pb-1 m-2"><img src="assets/images/icon/hcat2.png" alt=""></div>
                                    </a>
                                    <div class="position-absolute top-0 end-0" ><i class="far fa-window-close site-btn-close"></i></div>
                                </div>

                            </div>
                            <p><a href="#"> College 1 </a></p>
                            <p class="golden-color"><i class="fas fa-star"></i> 9/10</p>
                            </div>
                            <div class="d-none" id="compareoneDIV">
                            <select id="compareone" >
                                <option value="" selected disabled="true"></option>
                                @foreach($data as $k => $val)
                                        <option  value="{{$val->id}}">{{$val->name}}</option>
                                @endforeach
                            </select>
                            </div>
                        </th>
                        <th scope="col align-middle" >
                            <div id="compareTwoShow">
                            <div class="college-info-1">
                                <div class="cover-img position-relative box" style="background:url(assets/images/slider/s1.jpg);background-size:cover;">

                                    <a href="#"><div class="college-info-logo position-absolute bottom-0 start-0 px-2 pb-1 m-2"><img src="assets/images/icon/hcat2.png" alt=""></div>
                                    </a>
                                    <div class="position-absolute top-0 end-0" ><i class="far fa-window-close site-btn-close"></i></div>
                                </div>
                            </div>
                            <p><a href="#"> College 2 </a></p>
                            <!--<p class="golden-color"><i class="fas fa-star"></i> 7/10</p>-->
                            </div>
                            <div class="d-none" id="comparetwoDIV">
                                <select id="comparetwo" >
                                    <option value="" selected disabled="true"></option>
                                    @foreach($data as $k => $val)
                                        <option  value="{{$val->id}}">{{$val->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </th>
                        <th scope="col align-middle">
                            <div id="compareThreeShow">
                            <div class="college-info-1">
                                <div class="cover-img position-relative box" style="background:url(assets/images/slider/s1.jpg);background-size:cover;">

                                    <a href="#"><div class="college-info-logo position-absolute bottom-0 start-0 px-2 pb-1 m-2"><img src="assets/images/icon/hcat2.png" alt=""></div>
                                        <div class="position-absolute top-0 end-0" ><i class="far fa-window-close site-btn-close"></i></div>
                                    </a>
                                </div>
                            </div>
                            <p><a href="#"> College 3 </a></p>
                            <p class="golden-color"> - </p>
                            </div>
                            <div class="d-none" id="comparethreeDIV">
                                <select id="comparethree" >
                                    <option value="" selected disabled="true"></option>
                                    @foreach($data as $k => $val)
                                        <option  value="{{$val->id}}">{{$val->name}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr class="collegename">
                        <th scope="row">College Name</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr class="affiliate">
                        <th scope="row">Affiliate By</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr class="address">
                        <th scope="row">Address</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr class="state">
                        <th scope="row">State</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr class="city">
                        <th scope="row">City</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>
                    <tr class="course">
                        <th scope="row">Cousre</th>
                        <td>-</td>
                        <td>-</td>
                        <td>-</td>
                    </tr>

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
@endsection
