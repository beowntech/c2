<footer>
    <div class="container">
        <div class="row py-4">
            <div class="col-md-4">
                <a href="/"><img src="/assets/images/logo-1.png" class="site-logo" alt="Ok admission" srcset=""></a>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Quasi id voluptatem perspiciatis iste itaque molestias, quidem dolor omnis ea eligendi atque nihil aspernatur ipsam unde deleniti. Nisi incidunt totam dignissimos.</p>
        <ul class="list-inline social-links">
          <li class="list-inline-item"><a href="#"><i class="fab fa-facebook"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-instagram"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-twitter"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
          <li class="list-inline-item"><a href="#"><i class="fab fa-whatsapp"></i></a></li> 
        </ul>
      </div>
      <div class="col-md-2">
        <h2>Top Colleges</h2>
        <ul class="list-unstyled">
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"> <i class="fas fa-angle-double-right"></i> link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h2>Top Courses</h2>
        <ul class="list-unstyled">
        <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"> <i class="fas fa-angle-double-right"></i> link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
        </ul>
      </div>
      <div class="col-md-2">
        <h2>Top Exams</h2>
        <ul class="list-unstyled">
        <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"> <i class="fas fa-angle-double-right"></i> link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
          <li><a href="#"><i class="fas fa-angle-double-right"></i> Link Add</a></li>
            
        </ul>
      </div>
      <div class="col-md-2">
        <h2>Contact </h2>
        
      </div>
    </div>
  </div>
  <div class="container py-2">
    <div class="row border-top">
      <div class="col">
        <ul class="list-inline mb-0">
             <li class="list-inline-item"><a href="/">Home</a></li>
          <li class="list-inline-item"><a href="#">About Us</a></li>
          <li class="list-inline-item"><a href="#">Disclaimer</a></li>
          <li class="list-inline-item"><a href="/contact">Contact</a></li>
          <li class="list-inline-item"><a href="/privacy-policy">Privacy & Policy</a></li>
          <li class="list-inline-item"><a href="/terms">Terms of Use</a></li>
        </ul>
      </div>
    </div>
    <div class="row border-top">

      <div class="col">
        <p>Copyright © 2021. ok admission. </p>
      </div>
    </div>
  </div>
</footer>
<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">How Okadmission Helps you?</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body py-0">
                <div class="row">
                    <div class="col-md-4 bg-light pb-3">
                        <img src="/assets/images/site/popup-img.png" width="100%" alt="">
                    </div>
                    <div class="col-md-8">
                        <h2 class="site-title text-start">Register Now To Apply</h2>
                        <h3 class="site-title-sm text-start" id="quickEnqCollegName"> College Name, Location</h3>
                        <hr>
                        <form action="">
                            <div class="row mb-2">
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Full Name">
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="Email Address">
                                </div>
                            </div>
                            <div class="row">
                                <div class="col">
                                    <div class="input-group mb-3">
                                        <span class="input-group-text" id="basic-addon1">+91</span>
                                        <input type="number" class="form-control" placeholder="Contact Number" aria-describedby="basic-addon1">
                                    </div>
                                </div>
                                <div class="col">
                                    <input type="text" class="form-control" placeholder="City">
                                </div>
                            </div>
                            <div class="row mb-4">

                                <div class="col-6">
                                    <input type="text" class="form-control" placeholder="Intrested Course">
                                </div>
                            </div>
                            <p class="small">By submitting this form, you accept and agree to our <a href="#">Terms of Use</a> .</p>
                            <p><a href="#"> Already Registered? Click Here To Login.</a> <button type="button" class="btn site-btn-2 btn-sm float-end">Submit</button></p>
                        </form>

                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div class="offcanvas offcanvas-bottom" style="height: 34vh;" tabindex="-1" data-bs-scroll="true" id="offcanvasBottom" data-bs-backdrop="false" data-bs-keyboard="true" aria-labelledby="offcanvasBottomLabel">
    <div class="offcanvas-header" style="    padding: 5px 20px;">
        <h5 class="offcanvas-title" id="offcanvasBottomLabel">Compare Colleges</h5>
        <button type="button" class="btn-close text-reset closeoffCanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body small">
        <div class="container">
            <form action="/compare" method="GET">
            <div class="row">
                 <div class="col-md-9">
                    <div class="row">
                <div class="col-4 data-type-1 text-center ">
                    <div id="modalC1">
                    <a href="#!" class="addC">
                        <div class="p-3 icon-bx position-relative box">
                            <img src="/assets/images/icon/hcat1.png" width="65px" alt="">
                            <p>Add College</p>
                        </div>
                    </a>
                    </div>
                    <div class="d-none" id="modaloneDIV">
                        <select id="modaloneSelect" >
                            <option value="" selected disabled="true"></option>
                            @foreach($prop as $k => $val)
                                <option  value="{{$val->id}}">{{$val->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-4 data-type-1 text-center ">
                    <div id="modalC2">
                    <a href="#!" class="addC">
                        <div class="p-3 icon-bx position-relative box">
                            <img src="/assets/images/icon/hcat1.png" width="65px" alt="">
                            <p>Add College</p>
{{--                            <div class="position-absolute top-0 end-0" ><i class="far fa-window-close site-btn-close"></i></div>--}}
                        </div>
                    </a>
                    </div>
                    <div class="d-none" id="modaltwoDIV">
                        <select id="modaltwoSelect" >
                            <option value="" selected disabled="true"></option>
                            @foreach($prop as $k => $val)
                                <option  value="{{$val->id}}">{{$val->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                <div class="col-4 data-type-1 text-center ">
                    <div id="modalC3">
                    <a href="#!" class="addC">
                        <div class="p-3 icon-bx position-relative box">
                            <img src="/assets/images/icon/hcat1.png" width="65px" alt="">
                            <p>Add College</p>
{{--                            <div class="position-absolute top-0 end-0" ><i class="far fa-window-close site-btn-close"></i></div>--}}
                        </div>
                    </a>
                    </div>
                    <div class="d-none" id="modalthreeDIV">
                        <select id="modalthreeSelect" >
                            <option value="" selected disabled="true"></option>
                            @foreach($prop as $k => $val)
                                <option  value="{{$val->id}}">{{$val->name}}</option>
                            @endforeach
                        </select>
                    </div>
                </div>
                </div>
                </div>
                <div class="col-md-3 data-type-1 text-center ">
                    <div class="p-3 icon-bx">
                        <button class="btn site-btn-2">Compare</button>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>
</div>

<!-- Login Modal -->
<div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Register & Login Now</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-4 bg-light pb-3">
                        <img src="/assets/images/site/popup-img.png" width="100%" alt="">
                    </div>
                    <div class="col-md-8 loginForm">
                        <h2 class="site-title text-start">Login</h2>
                        <hr>
                        <form action="">
                            <div class="row mb-2">
                                <div class="col-md-12">
                                    <input type="text" class="form-control" placeholder="Email Address">
                                </div>
                                <div class="col-md-12 mt-2">
                                    <input type="text" class="form-control" placeholder="Password">
                                </div>
                            </div>
                            <p class="small">By submitting this form, you accept and agree to our <a href="#">Terms of Use</a> .</p>
                            <p><a href="#!" id="registerNow"> Not Registered Yet? Click Here To Register.</a> <button type="button" class="btn site-btn-2 btn-sm float-end">Login</button></p>
                        </form>
                    </div>
                    <div class="col-md-8 registerForm" style="display:none;">
                        <h2 class="site-title text-start">Register</h2>
                        <hr>
                        <form action="">
                            <div class="row mb-2">
                                <div class="col-md-12">
                                    <input type="text" class="form-control" placeholder="Name">
                                </div>
                                <div class="col-md-12 mt-2">
                                    <input type="text" class="form-control" placeholder="Email Address">
                                </div>
                                <div class="col-md-12 mt-2">
                                    <input type="text" class="form-control" placeholder="Password">
                                </div>
                                <div class="col-md-12 mt-2">
                                    <input type="text" class="form-control" placeholder="Confirm Password">
                                </div>
                            </div>
                            <p class="small">By submitting this form, you accept and agree to our <a href="#">Terms of Use</a> .</p>
                            <p><a href="#!" id="loginNow"> Already Registered? Click Here To Login.</a> <button type="button" class="btn site-btn-2 btn-sm float-end">Register</button></p>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>
<!-- Optional JavaScript; choose one of the two! -->

<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
<script src="{{asset('front/js/jquery.min.js')}}"></script>
<script src="{{asset('assets/js/main.js')}}"></script>
<!-- Option 2: Separate Popper and Bootstrap JS -->
<!--
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.min.js" integrity="sha384-lpyLfhYuitXl2zRZ5Bn2fqnhNAKOAaM/0Kr9laMspuaMiZfGmfwRNFh8HlMy49eQ" crossorigin="anonymous"></script>
-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/selectize.js/0.13.3/js/standalone/selectize.min.js" ></script>
<script src="{{asset('/assets/js/custom.js')}}"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<script src="/assets/dist/simple-lightbox.js?v2.4.1"></script>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    /* AppC */
    $(function () {
        
        var ctx = $('#myChart');
        var myChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
  labels: [
    'Payable Amount',
    'Total Interest',
  ],
  datasets: [{
    label: 'Education Loan',
    data: [100, 90],
    backgroundColor: [
      'rgb(255,91,0)',
      'rgb(54, 162, 235)',
    ],
  }]
},
    options: {
      circumference: Math.PI,
			rotation: 1.0 * Math.PI,
			responsive: true,
			legend: { position: 'top',},
			title: { display: true, text: 'Graphics' },
			animation: { animateScale: true, animateRotate: true },
			events: [],
		}
});



        function e(e) {
            if ((e = e.toString()).length > 9) return "overflow";
            if (n = ("000000000" + e).substr(-9).match(/^(\d{2})(\d{2})(\d{2})(\d{1})(\d{2})$/), n) {
                var t = "";
                return t += 0 != n[1] ? (l[Number(n[1])] || o[n[1][0]] + " " + l[n[1][1]]) + "crore " : "", t += 0 != n[2] ? (l[Number(n[2])] || o[n[2][0]] + " " + l[n[2][1]]) + "lakh " : "", t += 0 != n[3] ? (l[Number(n[3])] || o[n[3][0]] + " " + l[n[3][1]]) + "thousand " : "", t += 0 != n[4] ? (l[Number(n[4])] || o[n[4][0]] + " " + l[n[4][1]]) + "hundred " : "", t += 0 != n[5] ? ("" != t ? "and " : "") + (l[Number(n[5])] || o[n[5][0]] + " " + l[n[5][1]]) + "only " : ""
            }
        }

        function t() {
            var n = Math.round(r * i / (1 - Math.pow(1 / (1 + i), a))),
                t = r * i / (1 - Math.pow(1 / (1 + i), a)),
                l = t * a - r;
            $(".emiValue").text(n.toLocaleString("en-IN")), 
            $(".interestValue").text(Math.round(l).toLocaleString("en-IN")), 
            $(".TotalValue").text(Math.round(t * a).toLocaleString("en-IN"));
            //  myChart.data.datasets[0].data[1] = Math.round(l);
            //   myChart.data.datasets[0].data[0] = Math.round(t*a);
            //     myChart.update();
        }
        var r, a, i, l = ["", "one ", "two ", "three ", "four ", "five ", "six ", "seven ", "eight ", "nine ", "ten ", "eleven ", "twelve ", "thirteen ", "fourteen ", "fifteen ", "sixteen ", "seventeen ", "eighteen ", "nineteen "],
            o = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"];
        $("#loan-amount").slider({
            range: "min",
            value: 100000,
            min: 0,
            max: 9000000,
            step: 100000,
            slide: function (n, a) {
                $("#selected-amount").text((a.value)/100000), r = a.value, t()
            }
        }),
        $("#selected-amount").text(($("#loan-amount").slider("value"))/100000)
        var r = $("#loan-amount").slider("value");
        $("#interest-rate").slider({
            range: "min",
            value: 5,
            min: 5,
            max: 22.5,
            step: .05,
            slide: function (e, n) {
                console.log(n.value / 1200);
                $("#selected-interest").text(n.value), i = n.value / 1200, t()
            }
        }), $("#selected-interest").text($("#interest-rate").slider("value")), i = $("#interest-rate").slider("value") / 1200, $("#loan-duration").slider({
            range: "min",
            value: 1,
            min: 0,
            max: 35,
            step: .5,
            slide: function (e, n) {
                console.log(12 * n.value);
                $("#selected-duration").text(n.value), a = 12 * n.value, t()
            }
        }), $("#selected-duration").text($("#loan-duration").slider("value")), a = 12 * $("#loan-duration").slider("value"), t()
    });

    /* AppC */
</script>
<script>
    (function() {
        var $gallery = new SimpleLightbox('.gallery a', {});
        var $gallery = new SimpleLightbox('.gallery2 a', {});
    })();
</script>
</body>
</html>
