<style scoped>
    .con-input-upload{
        width: 120px !important;
        height: 120px !important;
    }
    .img-upload{
        width: 120px !important;
        height: 120px !important;
    }
</style>
<template>
    <div>
        <vx-card title="Add Course">
            <div class="vx-row">
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">College Category</h6>
                    <v-select v-model="selectedCatg" @input="getStream" :options="categories" :dir="$vs.rtl ? 'rtl' : 'ltr'" />
                </div>
                <div class="vx-col sm:w-1/3 w-full mb-2" style="display:none;" id="stream">
                    <h6 class="mb-1">Stream</h6>
                    <v-select v-model="selectedStream" :options="streams" @input="getSubStream" :dir="$vs.rtl ? 'rtl' : 'ltr'" />
                </div>
                <div class="vx-col sm:w-1/3 w-full mb-2" style="display:none;" id="substream">
                    <h6 class="mb-1">Substream</h6>
                    <v-select v-model="selctedSubstream" :options="substreams" :dir="$vs.rtl ? 'rtl' : 'ltr'" />
                </div>
            </div>
            <div class="vx-row mt-3">
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">Course Duration/Years (Only Numbers)</h6>
                    <vs-input type="number" style="width: 100%;" v-model="years" />
                </div>
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">Course Type</h6>
                    <vs-input style="width: 100%;" v-model="Ctype" />
                </div>
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">Fees (For Full Course)</h6>
                    <vs-input type="number" style="width: 100%;" v-model="fees" />
                </div>
            </div>
            <div class="vx-row mt-3">
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">Program Type (Example: Part Time)</h6>
                    <v-select v-model="time_type" :options="timeType" :dir="$vs.rtl ? 'rtl' : 'ltr'" />
                </div>
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">Eligibility</h6>
                    <vs-input style="width: 100%;" v-model="eligibility" />
                </div>
                <div class="vx-col sm:w-1/3 w-full mb-2">
                    <h6 class="mb-1">Upload Brochure</h6>
                    <input type="file" name="" v-on:change="onFileChange">
                </div>
            </div>
            <div class="vx-row mt-4">
                <div class="vx-col w-full mb-2">
            <vs-button @click="addRoom" style="float: right;width: 15%;" >Submit</vs-button>
                </div>
            </div>
        </vx-card>
    </div>
</template>
<script>
    import axios from "axios";
    import Input from "../forms/form-elements/input/Input";
    import flatPickr from 'vue-flatpickr-component';
    import 'flatpickr/dist/flatpickr.css';
    import vSelect from 'vue-select'
    import $ from 'jquery';

    export default {
        name: "add-room.vue",
        components: {Input, flatPickr,'v-select': vSelect,},
        data() {
            return {
                count:1,
                categories: [],
                selectedCatg: {},
                selectedStream: {},
                streams: [],
                substreams: [],
                selctedSubstream: [],
                eligibility: "",
                time_type: [],
                fees: null,
                Ctype: "",
                years: "",
                file: null,
                timeType: [
                    {
                    label: 'Part Time',
                    value: 1
                },
                    {
                        label: 'Full Time',
                        value: 0
                    }],
            }
        },
        methods:{
            addRoom(){
                const config = {
                    headers: { 'content-type': 'multipart/form-data' }
                }
                let fd = new FormData();
                fd.append("prop_id", localStorage.getItem('globalIns'));
                    fd.append("catg", this.selectedCatg.id);
                    fd.append("stream", this.selectedStream.id);
                    fd.append("substream", this.selctedSubstream.id);
                    fd.append("years", this.years);
                    fd.append("type", this.Ctype);
                    fd.append("price", this.fees);
                fd.append("progType", this.time_type.value);
                fd.append("eligibility", this.eligibility);
                fd.append("file", this.file);
                for (var pair of fd.entries()) {
                    console.log(pair[0]+ ', ' + pair[1]);
                }
                axios.post('/api/course/add',fd,config)
                    .then((res) => {
                        this.selectedCatg = [];
                        this.selectedStream = [];
                        this.selctedSubstream = [];
                        this.years = "";
                        this.Ctype = "";
                        this.time_type = [];
                        this.eligibility = "";
                        this.file = null;
                        // this.textarea = res.data;
                        console.log(res.data);
                    })
                    .catch((err) => {
                        // this.$vs.loading.close();
                        console.log(err)
                    })
            },
            onFileChange(e){
                // console.log(e.target.files[0]);
                this.file = e.target.files[0];
            },
            successUpload(e){
                this.originalImage = e.target.files[0];
            },
            getCategories(){
                axios.post('/api/categories/course-catg')
                    .then((res) => {
                        this.categories = res.data;
                        // this.getStream()
                    })
                    .catch((err) => {
                        // this.$vs.loading.close();
                        console.log(err)
                    })
            },
            getStream(){
                axios.post('/api/categories/course-stream',{
                    'id': this.selectedCatg.id,
                })
                    .then((res) => {
                        if(res.data != 0) {
                            $("#stream").show();
                            this.streams = res.data;
                        }else{
                            $("#stream").hide();
                        }
                    })
                    .catch((err) => {
                        // this.$vs.loading.close();
                        console.log(err)
                    })
            },
            getSubStream(){
                axios.post('/api/categories/course-sub-stream',{
                    'id': this.selectedStream.id,
                })
                    .then((res) => {
                        if(res.data != 0) {
                            $("#substream").show();
                            this.substreams = res.data;
                        }else{
                            $("#substream").hide();
                        }
                    })
                    .catch((err) => {
                        // this.$vs.loading.close();
                        console.log(err)
                    })
            },
        },
        mounted() {
            this.getCategories();
        }
    }
</script>
<style>
    .vs__actions{
        display: none !important;
    }
</style>
