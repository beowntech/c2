<!-- =========================================================================================
    File Name: ProgressInterminate.vue
    Description: Interminate progreebar
    ----------------------------------------------------------------------------------------
    Item Name: Vuexy - Vuejs, HTML & Laravel Admin Dashboard Template
      Author: Pixinvent
    Author URL: http://www.themeforest.net/user/pixinvent
========================================================================================== -->


<template>
    <vx-card title="Interminate" code-toggler>

        <p>You can have a progress bar with indeterminate value with the property indeterminate</p>

        <div class="mt-5">
            <vs-progress indeterminate color="primary"></vs-progress>
        </div>

        <template slot="codeContainer">
&lt;vs-progress indeterminate color=&quot;primary&quot;&gt;&lt;/vs-progress&gt;
        </template>

    </vx-card>
</template>
