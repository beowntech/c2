// axios
import axios from 'axios'

const domain = ""

export default axios.create({
  domain
  // You can add your headers here
})
